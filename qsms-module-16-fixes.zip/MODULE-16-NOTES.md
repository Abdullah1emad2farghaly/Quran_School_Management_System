# Module 16 — Schools (complete, with REST API): delivery notes
1. npm run db:migrate        (create-schools + add-schools-applicant-name + fix-schools-holds-name-check)
2. npm run typecheck && npm test
3. npm run test:db           (tests/db/schools.test.ts, plus the updated organizations / organization-country / geography DB tests; all always rolled back)
New: 11 endpoints under /api/v1/schools (docs/SCHOOLS.md, "HTTP API"). Public: POST /schools/main-submissions and /schools/sub-submissions (applicant account created through IAM, nothing granted; 10 per hour per IP, provisional).
Applicants set their password through the existing OTP flow: POST /api/v1/auth/password-recovery/request|verify|reset.
Permission matrix, D-1 and D-2 are NOT finalized; administrative endpoints are limited to an active Main Admin by the service (provisional).
Open decisions (docs/SCHOOLS.md, "BLOCKERS"): Main School applicant role mapping; "only Main Admin creates a Main School" versus public submission; phone-ownership verification; abuse-limit figure.
Not yet verified on your machine: migrations, typecheck, npm test (unit + API), test:db.
