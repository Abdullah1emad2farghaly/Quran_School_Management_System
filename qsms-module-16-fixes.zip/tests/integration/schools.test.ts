import express from 'express';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { registerAllErrorMessages } from '../../src/app/bootstrap/register-error-messages';
import { errorHandler, notFoundHandler } from '../../src/app/middleware/error-handler.middleware';
import { requestContextMiddleware } from '../../src/app/middleware/request-context.middleware';
import { createAuthRouter, createRequireAuthentication } from '../../src/modules/10-sessions-jwt/public';
import { createPublicSubmissionRateLimiter, createSchoolRouter } from '../../src/modules/16-schools/public';
import { createSchoolsApiHarness } from '../helpers/schools-api-harness';

const gps = { latitude: 30.0444, longitude: 31.2357, accuracyMeters: 12 };

async function build(options: { maxSubmissions?: number } = {}) {
  registerAllErrorMessages();
  const t = await createSchoolsApiHarness();
  const requireAuthentication = createRequireAuthentication(() => t.h.service);
  const app = express();
  app.use(requestContextMiddleware);
  app.use(express.json());
  app.use(
    '/api/v1/schools',
    createSchoolRouter({
      getService: () => t.service,
      requireAuthentication,
      publicSubmissionLimit: createPublicSubmissionRateLimiter({ maxRequests: options.maxSubmissions ?? 1000, windowMs: 60_000 }),
    }),
  );
  app.use('/api/v1/auth', createAuthRouter({ getService: () => t.h.service, requireAuthentication }));
  app.use(notFoundHandler);
  app.use(errorHandler);

  const login = async (u: { phone: string; password: string }) => {
    const res = await request(app).post('/api/v1/auth/login').send({ phone: u.phone, password: u.password });
    return { Authorization: `Bearer ${res.body.data.accessToken}` };
  };
  const admin = await t.h.createUser({ role: 'MAIN_ADMIN' });
  const adminAuth = await login(admin);
  const form = (over: { phone?: string; schoolName?: string; parentSchoolId?: string } = {}) => ({
    applicant: { name: 'أحمد محمد', phone: over.phone ?? '01112345678' },
    ...(over.parentSchoolId ? { parentSchoolId: over.parentSchoolId } : {}),
    school: { name: over.schoolName ?? 'مدرسة النور', governorateId: t.gov.id, gps },
  });
  const mainSchool = async (name = 'الرئيسية', phone = '01199990000') => {
    const res = await request(app).post('/api/v1/schools/main-submissions').send(form({ phone, schoolName: name }));
    return res.body.data.school as { id: string; status: string };
  };
  return { app, t, admin, adminAuth, login, form, mainSchool };
}

const base = '/api/v1/schools';

describe('POST /schools/main-submissions (public)', () => {
  it('creates the applicant account and an ACTIVE Main School without any login (201, standard envelope)', async () => {
    const { app, t, form } = await build();
    const res = await request(app).post(`${base}/main-submissions`).send(form());
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ success: true, data: { school: { type: 'MAIN', status: 'ACTIVE', applicantName: 'أحمد محمد' }, applicant: { accountCreated: true } } });
    expect(res.headers['x-request-id']).toBeTruthy();
    expect(res.body.requestId).toBe(res.headers['x-request-id']);
    const user = await t.h.identity.findByPhone('+201112345678');
    expect(res.body.data.applicant.userId).toBe(user!.id);
    expect(await t.h.roles.listActiveRoles(user!.id)).toEqual([]); // no role is granted by a public submission
    expect(JSON.stringify(res.body)).not.toMatch(/password|token/i);
  });

  it('answers an existing phone with the IAM conflict (409) and creates nothing; no login is needed and none is granted', async () => {
    const { app, t, form } = await build();
    const u = await t.h.createUser({ role: 'TEACHER' });
    const res = await request(app).post(`${base}/main-submissions`).send(form({ phone: u.phone }));
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe('USER_PHONE_ALREADY_EXISTS');
    expect(await t.h.roles.listActiveRoles(u.id)).toEqual(['TEACHER']);
    expect(t.schools.rows.size).toBe(0);
  });

  it('lets a logged-in user submit as themselves, and refuses another phone', async () => {
    const { app, t, form, login } = await build();
    const u = await t.h.createUser({ role: 'TEACHER' });
    const auth = await login(u);
    const ok = await request(app).post(`${base}/main-submissions`).set(auth).send(form({ phone: u.phone }));
    expect(ok.status).toBe(201);
    expect(ok.body.data.applicant).toEqual({ userId: u.id, accountCreated: false });
    const mismatch = await request(app).post(`${base}/main-submissions`).set(auth).send(form({ phone: '01155550000', schoolName: 'other' }));
    expect(mismatch.status).toBe(409);
    expect(mismatch.body.error.code).toBe('SCHOOL_APPLICANT_IDENTITY_MISMATCH');
  });

  it('rejects an invalid token instead of silently treating the caller as anonymous (401)', async () => {
    const { app, form } = await build();
    const res = await request(app).post(`${base}/main-submissions`).set('Authorization', 'Bearer not-a-token').send(form());
    expect(res.status).toBe(401);
  });

  it('validates the body: required fields, types and GPS (400 with field errors); business GPS accuracy is a 422', async () => {
    const { app, form } = await build();
    const empty = await request(app).post(`${base}/main-submissions`).send({});
    expect(empty.status).toBe(400);
    expect(empty.body.error.code).toBe('VALIDATION_FAILED');
    const fields = (empty.body.error.details.fields as { field: string }[]).map((d) => d.field);
    expect(fields).toEqual(expect.arrayContaining(['applicant.name', 'applicant.phone', 'school.name', 'school.governorateId', 'school.gps.latitude']));
    const wrongType = await request(app).post(`${base}/main-submissions`).send({ ...form(), school: { ...form().school, gps: { ...gps, latitude: '30.1' } } });
    expect(wrongType.status).toBe(400);
    const badPhone = await request(app).post(`${base}/main-submissions`).send(form({ phone: '12345' }));
    expect(badPhone.body.error.code).toBe('INVALID_PHONE_NUMBER');
    const accuracy = await request(app).post(`${base}/main-submissions`).send({ ...form(), school: { ...form().school, gps: { ...gps, accuracyMeters: 25 } } });
    expect(accuracy.body.error.code).toBe('GPS_ACCURACY_EXCEEDS_LIMIT');
    expect(accuracy.status).toBeGreaterThanOrEqual(400);
  });

  it('localizes error messages (Arabic by default, English on request)', async () => {
    const { app, t, form } = await build();
    const u = await t.h.createUser();
    const ar = await request(app).post(`${base}/main-submissions`).send(form({ phone: u.phone }));
    const en = await request(app).post(`${base}/main-submissions`).set('Accept-Language', 'en').send(form({ phone: u.phone, schoolName: 'x' }));
    expect(ar.body.error.message).not.toBe(en.body.error.message);
    expect(en.body.error.code).toBe('USER_PHONE_ALREADY_EXISTS');
  });

  it('limits public submissions per client (429 with Retry-After)', async () => {
    const { app, form } = await build({ maxSubmissions: 2 });
    for (let i = 0; i < 2; i += 1) {
      const ok = await request(app).post(`${base}/main-submissions`).send(form({ phone: `0111000000${i}`, schoolName: `s${i}` }));
      expect(ok.status).toBe(201);
    }
    const limited = await request(app).post(`${base}/sub-submissions`).send(form());
    expect(limited.status).toBe(429);
    expect(limited.body.error.code).toBe('RATE_LIMITED');
    expect(Number(limited.headers['retry-after'])).toBeGreaterThan(0);
  });
});

describe('POST /schools/sub-submissions (public) and the approval flow', () => {
  it('creates a PENDING request, then the Main Admin approves it and the applicant becomes its manager', async () => {
    const { app, t, form, adminAuth, mainSchool } = await build();
    const parent = await mainSchool();
    const submitted = await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: parent.id, phone: '01122223333' }));
    expect(submitted.status).toBe(201);
    expect(submitted.body.data.school).toMatchObject({ type: 'SUB', status: 'PENDING', parentSchoolId: parent.id });
    const applicantId = submitted.body.data.applicant.userId as string;
    expect(await t.h.roles.listActiveRoles(applicantId)).toEqual([]);

    const approved = await request(app).post(`${base}/${submitted.body.data.school.id}/approve`).set(adminAuth);
    expect(approved.status).toBe(200);
    expect(approved.body.data.school.status).toBe('ACTIVE');
    expect(approved.body.data.manager).toMatchObject({ userId: applicantId, isActive: true, source: 'SUB_SCHOOL_APPROVAL' });
    expect(await t.h.roles.listActiveRoles(applicantId)).toEqual(['SCHOOL_MANAGER']);
    expect(await t.service.isSchoolManager(applicantId, parent.id)).toBe(false);

    const again = await request(app).post(`${base}/${submitted.body.data.school.id}/approve`).set(adminAuth);
    expect(again.status).toBe(422);
    expect(again.body.error.code).toBe('SCHOOL_INVALID_STATUS_TRANSITION');
  });

  it('rejects an unknown or non-Main parent (422) and a malformed parent id (400)', async () => {
    const { app, form } = await build();
    const unknown = await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: '11111111-1111-4111-8111-111111111111' }));
    expect(unknown.status).toBe(422);
    expect(unknown.body.error.code).toBe('SCHOOL_PARENT_INVALID');
    const malformed = await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: 'nope' }));
    expect(malformed.status).toBe(400);
  });

  it('rejection needs a reason (400), then records it and assigns nothing; the account survives', async () => {
    const { app, t, form, adminAuth, mainSchool } = await build();
    const parent = await mainSchool();
    const submitted = await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: parent.id, phone: '01122224444' }));
    const id = submitted.body.data.school.id as string;
    const noReason = await request(app).post(`${base}/${id}/reject`).set(adminAuth).send({});
    expect(noReason.status).toBe(400);
    const rejected = await request(app).post(`${base}/${id}/reject`).set(adminAuth).send({ reason: 'الموقع غير مناسب' });
    expect(rejected.status).toBe(200);
    expect(rejected.body.data).toMatchObject({ status: 'REJECTED', rejectionReason: 'الموقع غير مناسب' });
    const applicantId = submitted.body.data.applicant.userId as string;
    expect(await t.h.roles.listActiveRoles(applicantId)).toEqual([]);
    expect(await t.h.identity.findById(applicantId)).toBeDefined();
    expect(t.managers.rows.size).toBe(0);
  });
});

describe('protected endpoints', () => {
  it('require authentication (401) and, for administrative actions, a Main Admin (403)', async () => {
    const { app, t, form, login, mainSchool } = await build();
    const parent = await mainSchool();
    const sub = (await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: parent.id, phone: '01122225555' }))).body.data.school.id as string;
    const teacher = await login(await t.h.createUser({ role: 'TEACHER' }));
    const gpsBody = { gps };
    const calls: [string, string, object?][] = [
      ['post', `${base}/${sub}/approve`],
      ['post', `${base}/${sub}/reject`, { reason: 'x' }],
      ['post', `${base}/${parent.id}/deactivate`],
      ['post', `${base}/${parent.id}/reactivate`],
      ['patch', `${base}/${sub}/gps`, gpsBody],
      ['put', `${base}/${parent.id}/manager`, { userId: '11111111-1111-4111-8111-111111111111' }],
      ['delete', `${base}/${parent.id}/manager`],
      ['get', base],
      ['get', `${base}/${sub}`],
    ];
    for (const [method, url, body] of calls) {
      const anonymous = await (request(app) as unknown as Record<string, (u: string) => request.Test>)[method]!(url).send(body ?? {});
      expect([method, url, anonymous.status]).toEqual([method, url, 401]);
    }
    for (const [method, url, body] of calls.slice(0, 7)) {
      const forbidden = await (request(app) as unknown as Record<string, (u: string) => request.Test>)[method]!(url).set(teacher).send(body ?? {});
      expect([method, url, forbidden.status, forbidden.body.error?.code]).toEqual([method, url, 403, 'SCHOOL_ACTION_NOT_ALLOWED']);
    }
    expect((await t.service.getById(sub)).status).toBe('PENDING');
  });

  it('GET /schools lists what the caller may see (paginated); GET /schools/:id hides what they may not', async () => {
    const { app, t, form, adminAuth, login, mainSchool } = await build();
    const parent = await mainSchool();
    const a = (await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: parent.id, phone: '01122226661', schoolName: 'فرع أ' }))).body.data;
    await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: parent.id, phone: '01122226662', schoolName: 'فرع ب' }));
    const all = await request(app).get(base).set(adminAuth).query({ pageSize: 2, sort: 'code' });
    expect(all.status).toBe(200);
    expect(all.body.meta).toMatchObject({ page: 1, pageSize: 2, total: 3, totalPages: 2 });
    const pending = await request(app).get(base).set(adminAuth).query({ 'filter[status]': 'PENDING' });
    expect(pending.body.meta.total).toBe(2);

    // the applicant must set a password through OTP recovery before logging in; here we log in as a user created by the harness instead
    const stranger = await login(await t.h.createUser({ role: 'TEACHER' }));
    expect((await request(app).get(base).set(stranger)).body.meta.total).toBe(0);
    expect((await request(app).get(`${base}/${a.school.id}`).set(stranger)).status).toBe(404);
    expect((await request(app).get(`${base}/${a.school.id}`).set(adminAuth)).status).toBe(200);
    expect((await request(app).get(`${base}/not-a-uuid`).set(adminAuth)).status).toBe(400);
    expect((await request(app).get(base).set(adminAuth).query({ bogus: '1' })).status).toBe(400); // unknown query parameter
  });

  it('the Main Admin can correct a PENDING GPS, deactivate/reactivate and assign/revoke a manager over HTTP', async () => {
    const { app, t, form, adminAuth, mainSchool } = await build();
    const parent = await mainSchool();
    const sub = (await request(app).post(`${base}/sub-submissions`).send(form({ parentSchoolId: parent.id, phone: '01122227771' }))).body.data.school.id as string;
    const fix = { latitude: 30.05, longitude: 31.24, accuracyMeters: 8 };
    const corrected = await request(app).patch(`${base}/${sub}/gps`).set(adminAuth).send({ gps: fix });
    expect(corrected.status).toBe(200);
    expect(corrected.body.data.gps).toEqual(fix);
    await request(app).post(`${base}/${sub}/approve`).set(adminAuth);
    const locked = await request(app).patch(`${base}/${sub}/gps`).set(adminAuth).send({ gps });
    expect(locked.body.error.code).toBe('SCHOOL_GPS_LOCKED');

    expect((await request(app).post(`${base}/${parent.id}/deactivate`).set(adminAuth)).body.data.status).toBe('INACTIVE');
    expect((await request(app).post(`${base}/${parent.id}/reactivate`).set(adminAuth)).body.data.status).toBe('ACTIVE');
    const manager = await t.h.createUser();
    const assigned = await request(app).put(`${base}/${parent.id}/manager`).set(adminAuth).send({ userId: manager.id });
    expect(assigned.status).toBe(200);
    expect(assigned.body.data).toMatchObject({ userId: manager.id, isActive: true, source: 'MAIN_ADMIN_ASSIGNMENT' });
    const revoked = await request(app).delete(`${base}/${parent.id}/manager`).set(adminAuth);
    expect(revoked.body.data.isActive).toBe(false);
  });
});

describe('no account takeover through a phone number', () => {
  it('a known phone neither logs in nor returns the account: the submission conflicts, and a new account cannot be entered with a phone-derived password', async () => {
    const { app, t, form } = await build();
    const created = await request(app).post(`${base}/main-submissions`).send(form({ phone: '01166667777' }));
    expect(created.status).toBe(201);
    for (const password of ['7777', '01166667777', '+201166667777']) {
      const login = await request(app).post('/api/v1/auth/login').send({ phone: '01166667777', password });
      expect([password, login.status]).toEqual([password, 401]);
    }
    const second = await request(app).post(`${base}/main-submissions`).send(form({ phone: '+20 116 666 7777', schoolName: 'second' }));
    expect(second.status).toBe(409);
    expect(second.body.data).toBeUndefined();
    expect(t.schools.rows.size).toBe(1);
  });
});
