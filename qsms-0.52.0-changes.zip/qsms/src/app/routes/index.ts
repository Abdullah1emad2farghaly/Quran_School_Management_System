import { Router } from 'express';
import { requirePermission } from '../../config/authorization';
import { requireAuthentication, requireAuthenticationAllowingPasswordChange, getSessionService } from '../../config/sessions';
import { getOrganizationRegistrationService, getSchoolService, PUBLIC_SUBMISSION_RATE_LIMIT } from '../../config/schools';
import { getGeographyService } from '../../config/geography';
import { getOrganizationService } from '../../config/organization';
import { getParentService } from '../../config/parents';
import { getTeacherService } from '../../config/teachers';
import { getStudentService } from '../../config/students';
import { getExcelImportService } from '../../config/excel-import';
import { getGroupService } from '../../config/groups';
import { getAuditQueryService } from '../../config/audit';
import { getAttendanceService } from '../../config/attendance';
import { getEvaluationService } from '../../config/evaluations';
import { getExamService } from '../../config/exams';
import { getNotificationService, getPushSubscriptionService } from '../../config/notifications';
import { getPaymentService } from '../../config/payments';
import { getReportService } from '../../config/report-modules';
import { getCollectorService, getSubscriptionGroupService, getSubscriptionService } from '../../config/subscriptions';
import { getMemorizationService } from '../../config/memorization';
import { getRevisionService } from '../../config/revision';
import { getClassSessionService } from '../../config/class-sessions';
import { getGroupScheduleService } from '../../config/schedules';
import { getQuranStructureService } from '../../config/quran';
import { getPasswordRecoveryService } from '../../config/password-recovery';
import { createAuthRouter } from '../../modules/10-sessions-jwt/public';
import { createRecoveryRouter } from '../../modules/11-otp-password-recovery/public';
import { createGeographyRouter } from '../../modules/14-geography/public';
import { createOrganizationRouter, createPublicSubmissionRateLimiter, createSchoolRouter } from '../../modules/16-schools/public';
import { createParentRouter } from '../../modules/17-parents/public';
import { createTeacherRouter } from '../../modules/18-teachers/public';
import { createStudentRouter } from '../../modules/19-students/public';
import { createExcelImportRouter } from '../../modules/36-excel-import/public';
import { createGroupRouter } from '../../modules/20-groups/public';
import { createScheduleRouter } from '../../modules/23-group-schedules/public';
import { createSessionRouter } from '../../modules/24-sessions/public';
import { createAuditRouter } from '../../modules/35-history-audit/public';
import { createAttendanceRouter } from '../../modules/26-attendance/public';
import { createEvaluationRouter } from '../../modules/29-evaluations/public';
import { createExamRouter } from '../../modules/30-exams/public';
import { createNotificationRouter } from '../../modules/31-notifications-core/public';
import { createSubscriptionRouter } from '../../modules/33-subscriptions/public';
import { createPaymentRouter } from '../../modules/34-payments-collection/public';
import { createReportRouter } from '../../modules/38-report-modules/public';
import { createMemorizationRouter } from '../../modules/27-memorization/public';
import { createRevisionRouter } from '../../modules/28-revision/public';
import { createQuranRouter } from '../../modules/21-quran-structure/public';
import { healthRouter } from './health.routes';

export const API_BASE_PATH = '/api/v1';

/** Module routers are mounted here as their phases are implemented. */
export function buildApiRouter(): Router {
  const router = Router();
  router.use('/health', healthRouter);
  router.use('/geography', createGeographyRouter({ getGeography: getGeographyService, getOrganizations: getOrganizationService }));
  router.use('/auth/password-recovery', createRecoveryRouter({ getService: getPasswordRecoveryService }));
  router.use(
    '/organizations',
    createOrganizationRouter({
      getService: getOrganizationRegistrationService,
      requireAuthentication,
      requirePermission,
      publicSubmissionLimit: createPublicSubmissionRateLimiter(PUBLIC_SUBMISSION_RATE_LIMIT),
    }),
  );
  router.use(
    '/schools',
    createSchoolRouter({
      getService: getSchoolService,
      requireAuthentication,
      requirePermission,
      publicSubmissionLimit: createPublicSubmissionRateLimiter(PUBLIC_SUBMISSION_RATE_LIMIT),
    }),
  );
  router.use('/parents', createParentRouter({ getService: getParentService, requireAuthentication, requirePermission }));
  router.use('/teachers', createTeacherRouter({ getService: getTeacherService, requireAuthentication, requirePermission }));
  router.use('/students', createStudentRouter({ getService: getStudentService, requireAuthentication, requirePermission }));
  router.use('/groups', createGroupRouter({ getService: getGroupService, requireAuthentication, requirePermission }));
  router.use('/group-schedules', createScheduleRouter({ getService: getGroupScheduleService, requireAuthentication, requirePermission }));
  router.use('/sessions', createSessionRouter({ getService: getClassSessionService, requireAuthentication, requirePermission }));
  router.use('/audit-logs', createAuditRouter({ getService: getAuditQueryService, requireAuthentication, requirePermission }));
  router.use('/attendance', createAttendanceRouter({ getService: getAttendanceService, requireAuthentication, requirePermission }));
  router.use('/memorization', createMemorizationRouter({ getService: getMemorizationService, getQuran: getQuranStructureService, requireAuthentication, requirePermission }));
  router.use('/revision', createRevisionRouter({ getService: getRevisionService, getQuran: getQuranStructureService, requireAuthentication, requirePermission }));
  router.use('/evaluations', createEvaluationRouter({ getService: getEvaluationService, requireAuthentication, requirePermission }));
  router.use('/exams', createExamRouter({ getService: getExamService, requireAuthentication, requirePermission }));
  router.use('/subscriptions', createSubscriptionRouter({ getSubscriptions: getSubscriptionService, getCollectors: getCollectorService, getGroups: getSubscriptionGroupService, requireAuthentication, requirePermission }));
  router.use('/payments', createPaymentRouter({ getPayments: getPaymentService, requireAuthentication, requirePermission }));
  router.use('/reports', createReportRouter({ getReports: getReportService, requireAuthentication }));
  router.use('/notifications', createNotificationRouter({ getNotifications: getNotificationService, getPush: getPushSubscriptionService, requireAuthentication }));
  router.use('/excel-imports', createExcelImportRouter({ getService: getExcelImportService, getSchools: getSchoolService, requireAuthentication, requirePermission }));
  router.use('/quran', createQuranRouter({ getService: getQuranStructureService, requireAuthentication, requirePermission }));
  router.use('/auth', createAuthRouter({ getService: getSessionService, requireAuthentication, requireAuthenticationAllowingPasswordChange }));
  return router;
}
