# Architecture

Modular monolith with Clean Architecture, strong module boundaries, domain events with a transactional outbox, and selective CQRS (reporting). No microservices.

## Layers per module
`domain` (no Express/Sequelize) → `application` (use cases, ports) → `infrastructure` (Sequelize, queues, storage) → `presentation/http` (thin controllers, validators, serializers) → `public` (contracts/DTOs/events other modules may use).

## Rules
- Cross-module access only via `public/` contracts, DTOs, and events.
- Sequelize models are private to their owning module.
- No circular dependencies; use shared kernel, contracts, or events instead.
- Backend is the final security boundary.
- Business and persistence changes + outbox event commit in one transaction.

## Foundation conventions (bootstrap)
- Base path: `/api/v1`.
- Success: `{ "success": true, "data": ..., "requestId": "..." }`.
- Error: `{ "success": false, "error": { "code", "message", "locale", "requestId" } }`. Codes are language-independent.
- Request ID: reuse a safe `X-Request-Id`/`X-Correlation-Id` (`[A-Za-z0-9._-]{8,64}`), else generate; echoed in `X-Request-Id`.
- Locale: user preference > `Accept-Language` > default `ar`; fallback `en`.
- Timestamps stored in UTC; business timezone `Africa/Cairo`.
- Request context via `AsyncLocalStorage` (Module 05 area).

## Bootstrap placement notes
Bootstrap pieces live in `src/app` and `src/config`; their module homes (01–05) are filled in during their phases. Base `AppError` and error codes sit in `00-shared-kernel`.

## Shared Kernel (Module 00)
Generic, business-free building blocks only: errors (code + kind), entity/aggregate/value-object bases, UUID helpers, domain event shape, `Clock`, `UnitOfWork`, business-time and pagination helpers. It contains no business concepts and imports nothing from other modules.

## Database & transactions (Module 02)
Business operations that touch several resources run inside `UnitOfWork.run`. Sequelize transactions never leave infrastructure; see `docs/DATABASE.md`.

## Errors & localization (Module 03)
Domain code throws `AppError(code, kind, details?, params?)`. Only the HTTP boundary turns it into a localized response via Module 03; see `docs/LOCALIZATION.md`.

## Events & outbox (Module 06)
Asynchronous side effects go through `Business Action → Domain Event → Outbox → Handlers`; see `docs/EVENTS-OUTBOX.md`.

## Files (Module 07)
Uploaded Excel files are stored privately (no public URLs) behind `FileService`, with content-based validation and SHA-256 integrity checks; see `docs/FILES.md`.

## Identity (Module 08)
The login identity (normalized phone, bcrypt hash, ACTIVE/INACTIVE) is owned by `IdentityService`; other modules use only its public contract and authorize their own callers. No HTTP routes until Modules 10 and 12; see `docs/IDENTITY.md`.

## Roles & permissions (Module 09)
Roles are a fixed catalog; assignments keep full history; role -> permission grants are registered by each owning module and are deny-by-default. Module 09 does not authorize its callers and has no HTTP routes until Modules 10 and 12; see `docs/ROLES.md`.

## Sessions & authentication (Module 10)
Login, refresh-token rotation, logout and access-token verification. One active session per user; refresh tokens stored only as keyed hashes; each protected request checks the session and the user. Authentication only: authorization is Module 12. See `docs/SESSIONS.md`.

## OTP & password recovery (Module 11)
Forgot-password with an OTP and a single-use reset token; keyed-hash storage, no account enumeration, concurrency-safe MySQL rate limits, OTP delivery behind the `OtpSender` port (provider chosen later). A reset revokes all sessions through Module 10. See `docs/PASSWORD-RECOVERY.md`.

## Authorization engine (Module 12)
Roles -> permissions -> scope -> ownership, deny by default and fail closed. Each module registers its own permissions (with an explicit management/reporting/unscoped policy) and the scope/ownership resolvers for the data it owns; routes use `requirePermission`, other code injects `Authorizer`. Module 12 defines no permissions or endpoints and owns no organizational data. It also provides the one-time first-Main-Admin CLI. See `docs/AUTHORIZATION.md` and the central `docs/AUTHORIZATION-MATRIX.md`.

## Organizations (Module 13)
Owns the organizations (many; each with a required country and its own address, a system-wide unique name and administrator links that give the MAIN_ADMIN role its organization scope) and exposes the read-only `OrganizationLookup` contract. The bootstrap CLI creates the first organization; organizations are registered through the Module 16 endpoint `POST /organizations`. See `docs/ORGANIZATION.md`.

## Geography (Module 14)
Global, organization-independent reference data exposed through the read-only `GeographyLookup` contract (including `validateHierarchy` for Unified Address and Schools). Reference data is loaded by the idempotent `seed:geography` CLI; no endpoints, permissions, deletion or events. See `docs/GEOGRAPHY.md`.

## Unified Address (Module 15)
Pure application logic (no tables, no migration, no endpoints, no permissions, no events): normalization, raw-text parsing and validation of a **Parent Address** (registered Governorate of the Main Organization's country + free-text Center/City and Village). Depends only on the public contracts of Module 13 (`OrganizationLookup`) and Module 14 (`GeographyLookup`); exposes `UnifiedAddressLookup`. The Parents module (17) owns the persistence and history of the address. School addresses keep their structured rules and do not go through this module. See `docs/UNIFIED-ADDRESS.md`.

## Schools (Module 16)
Main Schools and Sub-School requests, the school-scoped manager link with history, GPS rules and gap-free codes. Depends only on the public contracts of Modules 00, 02, 03, 06, 08 (identity), 09 (roles), 13 (organization) and 14 (geography). Approval (school ACTIVE + manager link + SCHOOL_MANAGER role + history + events) runs in one UnitOfWork transaction. Has its own REST API under `/api/v1/schools` (public submissions with applicant account creation through IAM, approval/rejection, reads, lifecycle) and no permission-registry entries yet (matrix deferred); downstream modules use `SchoolLookup`. See `docs/SCHOOLS.md`.
