# CLAUDE CODE — MASTER PROJECT IMPLEMENTATION PROMPT

# Quran School Management System

# Master Specification + Architecture + Implementation Rules

# Version 1.0

* * *

# 1\. ROLE AND RESPONSIBILITY

You are the primary software engineer responsible for implementing the entire:

**Multi-School / Multi-Branch Quran School Management System**

You are working inside ONE repository and ONE continuous project context.

The project must be implemented **module-by-module**, according to the approved module map and implementation order defined in this document.

This document is the:

> **SINGLE SOURCE OF TRUTH**

for the system.

You MUST NOT invent, assume, simplify, remove, reinterpret, or modify business rules defined here.

If implementation reveals a genuinely missing business decision that changes system behavior:

```plaintext
STOP
↓
Identify the missing business decision
↓
Ask the user
↓
Wait for explicit approval
↓
Update the Master Specification / project documentation
↓
Continue implementation
```

Do NOT silently make business decisions.

Technical implementation decisions that do NOT change business behavior may be made by you when necessary, provided they respect this architecture and do not violate any approved business rule.

* * *

# 2\. PRIMARY OBJECTIVES

The final system must be:

-   Production-oriented

-   Secure

-   Modular

-   Maintainable

-   Scalable

-   Testable

-   Multi-school

-   Multi-branch

-   Role-based

-   Scope-aware

-   Ownership-aware

-   History-aware

-   Audit-aware

-   Localization-ready

-   Transaction-safe

-   API-first

-   Backend-enforced

The backend is the final security boundary.

Frontend restrictions must NEVER be considered authorization.

* * *

# 3\. DEVELOPMENT PHILOSOPHY

The system must be designed in this order:

```plaintext
Requirements
↓
Business Logic
↓
Roles
↓
Permissions
↓
Scopes
↓
Ownership
↓
Workflows
↓
Smart Guards
↓
Notifications
↓
Historical Rules
↓
Reporting
↓
Database
↓
Backend/API
↓
Frontend
```

Do NOT start by designing database tables and then invent business behavior around them.

Business logic owns the database design, not the opposite.

* * *

# 4\. BACKEND ARCHITECTURE

Use:

> Modular Monolith + Clean Architecture + Strong Module Boundaries

with:

-   Domain Events

-   Transactional Operations

-   Transactional Outbox

-   Selective CQRS where useful

-   Strong authorization boundaries

-   Module-owned infrastructure

-   Module-owned persistence

-   Explicit public contracts

Do NOT build microservices.

Do NOT create a distributed architecture.

Do NOT over-engineer CQRS.

Use CQRS only where read/write separation provides real value, especially reporting/read-heavy workflows.

* * *

# 5\. TECHNOLOGY STACK

Use:

-   Node.js

-   Express

-   TypeScript

-   TypeScript strict mode

-   Sequelize ORM

-   MySQL

-   express-validator

-   dotenv

-   cors

-   jsonwebtoken

-   bcryptjs

-   nodemon / tsx

-   sequelize-cli

Where background processing is required:

-   BullMQ

-   Redis

Use package versions that are mutually compatible and currently stable.

Do NOT replace the approved stack without explicit approval.

* * *

# 6\. API

Base API:

```plaintext
/api/v1
```

API must use:

-   consistent response structure

-   consistent error structure

-   stable error codes

-   pagination

-   whitelisted sorting

-   whitelisted filtering

-   request/correlation IDs

-   localized user-facing messages

Default pagination:

```plaintext
default = 20
maximum = 100
```

Never allow arbitrary database sorting/filtering fields from clients.

* * *

# 7\. REQUEST / CORRELATION ID

Every request must have a request/correlation ID.

It must be usable in:

-   logs

-   errors

-   audits

-   troubleshooting

-   relevant API responses

If the client provides an acceptable correlation/request ID, validate and safely reuse it according to the implementation policy.

Otherwise generate one.

* * *

# 8\. LOCALIZATION

Supported locales:

```plaintext
ar
en
```

Default:

```plaintext
ar
```

Fallback:

```plaintext
en
```

Locale resolution priority:

```plaintext
Explicit User Preference
↓
Request Locale / Accept-Language
↓
System Default
```

User-facing errors must include:

-   stable language-independent error code

-   localized message

-   locale

-   request ID where applicable

Error codes must NEVER depend on language.

* * *

# 9\. PROJECT ARCHITECTURE

Use the following overall structure.

```plaintext
project-root/
│
├── src/
│   │
│   ├── app/
│   │   ├── bootstrap/
│   │   ├── middleware/
│   │   ├── routes/
│   │   └── server.ts
│   │
│   ├── config/
│   │
│   └── modules/
│       │
│       ├── 00-shared-kernel/
│       ├── 01-configuration/
│       ├── 02-database/
│       ├── 03-error-localization/
│       ├── 04-validation-api/
│       ├── 05-logging-request-context/
│       ├── 06-domain-events-outbox/
│       ├── 07-file-infrastructure/
│       │
│       ├── 08-identity-core/
│       ├── 09-roles-permissions/
│       ├── 10-sessions-jwt/
│       ├── 11-otp-password-recovery/
│       ├── 12-authorization-engine/
│       │
│       ├── 13-organization-core/
│       ├── 14-geography/
│       ├── 15-unified-address/
│       ├── 16-schools/
│       │
│       ├── 17-parents/
│       ├── 18-teachers/
│       ├── 19-students/
│       │
│       ├── 20-groups/
│       ├── 21-quran-structure/
│       ├── 22-quran-range-engine/
│       ├── 23-group-schedules/
│       ├── 24-sessions/
│       │
│       ├── 25-smart-guard/
│       ├── 26-attendance/
│       ├── 27-memorization/
│       ├── 28-revision/
│       ├── 29-evaluations/
│       ├── 30-exams/
│       │
│       ├── 31-notifications-core/
│       ├── 32-notification-rules/
│       ├── 33-subscriptions/
│       ├── 34-payments-collection/
│       ├── 35-history-audit/
│       │
│       ├── 36-excel-import/
│       ├── 37-reports-core/
│       ├── 38-report-modules/
│       ├── 39-file-excel-access/
│       │
│       └── 40-integration-e2e/
│
├── database/
│   ├── migrations/
│   └── seeders/
│
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── docs/
│   ├── MASTER-SPECIFICATION.md
│   ├── ARCHITECTURE.md
│   ├── MODULE-MAP.md
│   ├── IMPLEMENTATION-STATUS.md
│   └── PROJECT-CHANGELOG.md
│
├── .env.example
├── .gitignore
├── package.json
├── tsconfig.json
├── sequelize.config.*
└── README.md
```

The exact extension of configuration files may follow the chosen Sequelize/TypeScript setup, but consistency is mandatory.

* * *

# 10\. MODULE INTERNAL ARCHITECTURE

Every business module must follow:

```plaintext
Module
├── Domain
├── Application
├── Infrastructure
├── Presentation
└── Public
```

Recommended structure:

```plaintext
XX-module/
│
├── domain/
│   ├── entities/
│   ├── value-objects/
│   ├── services/
│   ├── events/
│   ├── repositories/
│   └── contracts/
│
├── application/
│   ├── use-cases/
│   ├── dto/
│   ├── services/
│   └── ports/
│
├── infrastructure/
│   ├── persistence/
│   │   └── sequelize/
│   │       ├── models/
│   │       ├── repositories/
│   │       └── mappers/
│   ├── services/
│   └── jobs/
│
├── presentation/
│   └── http/
│       ├── controllers/
│       ├── routes/
│       ├── validators/
│       └── serializers/
│
└── public/
    ├── contracts/
    ├── dto/
    └── events/
```

This structure is the implementation architecture.

* * *

# 11\. CLEAN ARCHITECTURE RULES

## Domain

Domain must contain business concepts.

Domain MUST NOT depend on:

-   Express

-   Sequelize

-   HTTP

-   controllers

-   infrastructure

-   database implementation

## Application

Application coordinates use cases.

Application depends on:

-   domain

-   ports

-   public contracts

Application must NOT contain HTTP-specific implementation.

## Infrastructure

Infrastructure implements:

-   repositories

-   Sequelize models

-   persistence

-   external services

-   queues

-   background jobs

-   storage

## Presentation

Presentation contains:

-   controllers

-   routes

-   HTTP validators

-   serializers

-   request/response mapping

Controllers must remain thin.

## Public

Public exposes only contracts required by other modules.

Other modules must NOT access private implementation.

* * *

# 12\. MODULE BOUNDARY RULES

A module may depend on another module only through:

-   Public Domain Contracts

-   Public Application Contracts

-   Public DTO Contracts

-   Public Events

A module MUST NOT depend on:

-   another module's private services

-   private repositories

-   internal Sequelize models

-   internal database tables

-   internal infrastructure

-   private helpers

No circular dependencies.

If two modules appear to require each other:

```plaintext
A → B
B → A
```

Do NOT create direct circular imports.

Instead:

-   move a generic abstraction to Shared Kernel when appropriate

-   use a public contract

-   use a domain event

-   restructure ownership

* * *

# 13\. OWNERSHIP RULE

Every business concept must have exactly one owning module.

Other modules may reference it.

They must not duplicate its business ownership.

Examples:

-   School belongs to Schools module.

-   Teacher belongs to Teachers module.

-   Student belongs to Students module.

-   Group belongs to Groups module.

-   Session belongs to Sessions module.

-   Attendance belongs to Attendance module.

-   Memorization belongs to Memorization module.

-   Subscription belongs to Subscriptions module.

-   Payment belongs to Payments module.

* * *

# 14\. DATABASE OWNERSHIP

Sequelize models are internal to their owning module.

Do NOT allow other modules to directly query another module's Sequelize models.

Do NOT allow other modules to directly depend on internal tables.

Cross-module data access must happen through:

-   public application contracts

-   public domain contracts

-   events

-   appropriate read/query contracts

Transactions must be abstracted.

Do not expose Sequelize transaction internals throughout the entire application.

* * *

# 15\. TRANSACTIONS

Multi-resource business operations must use transactions.

Important examples:

-   user + role assignment

-   school creation

-   sub-school approval

-   student/group changes

-   payment operations

-   Excel import

-   business action + outbox event

Excel import must be atomic.

If a critical failure happens:

```plaintext
ROLLBACK EVERYTHING
```

No partially imported dataset.

* * *

# 16\. DOMAIN EVENTS / OUTBOX

Business actions that require asynchronous side effects must use:

```plaintext
Business Action
↓
Domain Event
↓
Transactional Outbox
↓
Notification / Background Processing
```

The business transaction and outbox record must be committed atomically.

Notification delivery failure must never roll back an already successful business transaction.

Persistence is the source of truth.

Realtime delivery is not the source of truth.

* * *

# 17\. MASTER BUSINESS SPECIFICATION

## 17.1 SYSTEM TYPE

The system is a:

**Multi-School / Multi-Branch Quran School Management System**

V1 includes:

-   Main Organization

-   Schools (every school belongs directly to an Organization; there is no Main School / Sub-School distinction)

-   Geography

-   Address

-   Users

-   Authentication

-   Sessions

-   Roles

-   Permissions

-   Scopes

-   Ownership

-   Parents

-   Teachers

-   Students

-   Groups

-   Quran

-   Schedules

-   Sessions

-   Attendance

-   Memorization

-   Revision

-   Evaluations

-   Exams

-   Subscriptions

-   Payments

-   Notifications

-   Audit

-   Excel Import

-   Reports

-   File access

Competition is V2.

Do NOT implement Competition in V1.

* * *

# 18\. ROLES

V1 roles are EXACTLY:

```plaintext
Main Admin
Organization Manager
Governorate Manager
Center Manager
Village Manager
School Manager
Teacher
Student
Parent
Subscription Collector
```

There is:

-   NO Supervisor role.

-   NO Competition Manager role.

Main Admin and Organization Manager (approved amendment):

-   Main Admin (`MAIN_ADMIN`) is the PLATFORM-WIDE administrator. It is a system-level role, not scoped to one Organization, and it is not an Organization Manager under another name. Platform-wide scope does not mean unlimited access: it holds only the platform permissions that are explicitly registered and approved (none for school or organization operations yet).

-   Organization Manager (`ORGANIZATION_MANAGER`) is the manager of ONE specific Organization. Every assignment is tied to a specific Organization (the organization manager link); the manager can view all schools of that Organization and perform only the approved management operations within it, never in another Organization, and receives no platform-wide privilege. The Organization scope is enforced on the server by the Authorization Engine on every applicable operation.

-   The first Main Admin is created by a platform-level bootstrap that is independent of any Organization.

Student is a business entity only in V1.

Student has:

-   no login

-   no password

-   no access token

-   no refresh token

-   no session

* * *

# 19\. MULTIPLE ROLES

A User may have multiple roles if identity/business rules allow it.

Example:

```plaintext
One User
├── Parent
└── Teacher
```

Role assignments must retain history:

```plaintext
assignedAt
assignedBy
revokedAt
revokedBy
```

A user must always have at least one active role.

Direct user-specific permissions are NOT used in V1.

Use RBAC.

* * *

# 20\. AUTHORIZATION MODEL

Authorization follows:

```plaintext
User
↓
Authentication
↓
Roles
↓
Permissions
↓
Scope
↓
Organization
↓
School
↓
Resource
↓
Ownership
↓
Action
↓
Business Rules
↓
Smart Guards
↓
ALLOW / REJECT
```

Frontend hiding is NOT authorization.

Reporting scope does NOT grant management permissions.

* * *

# 21\. USER IDENTITY

Login identifier:

```plaintext
Phone Number
```

One phone number can belong to only one User globally.

Phone numbers must be:

-   normalized

-   validated

-   canonicalized

-   uniquely constrained

Prefer E.164 representation.

Rules:

```plaintext
Same phone + same identity
→ reuse User

Same phone + different identity
→ conflict
→ NEVER automatic merge
```

* * *

# 22\. USER LIFECYCLE

```plaintext
ACTIVE
↓
INACTIVE
↓
ACTIVE
```

Deactivation:

-   is reversible

-   invalidates active sessions

-   blocks protected actions

-   preserves history

* * *

# 23\. PASSWORD POLICY

Password length:

```plaintext
4–12 characters
```

Allowed:

-   digits only

-   letters only

-   letters + digits

-   optionally special characters

No mandatory composition requirement.

Passwords must always be hashed.

Never store plaintext passwords.

* * *

# 24\. INITIAL PASSWORD

For parent creation:

```plaintext
Initial password = last 4 digits of phone number
```

Initial password does NOT force a password change.

System only recommends changing it.

**Approved amendment (Module 17):** for a NEWLY created Parent account the initial password MUST be changed before normal use: the account is flagged `must_change_password`, and until it is changed the backend allows only the password change and logout. The requirement belongs to the ACCOUNT, not to the Parent role: reusing an existing account never creates, clears or resets it, and never changes its password.

* * *

# 25\. SESSION / JWT

Each authenticated session uses:

-   accessToken

-   refreshToken

Access token:

```plaintext
15 minutes
```

Refresh token:

```plaintext
30 days
```

Refresh tokens must be:

-   hashed

-   linked to user/session

-   expiration-aware

-   revocable

-   rotated

Refresh token reuse must be rejected.

Only one active session/device per User.

When the user logs in from another device:

```plaintext
Revoke old active session
↓
Create new active session
```

Support:

-   logout current session

-   logout all sessions

**Approved amendment (Module 10, owner decision of 2026-11-04, supersedes "Only one active session/device per User" and the "Revoke old active session" flow above; the original text is kept as the historical record):**

-   An account may have up to **THREE concurrent active sessions**, for EVERY role without exception. Each device/browser has its own independent session, access-token and refresh-token lifecycle (rotation, reuse detection and revocation affect only that session).

-   A login NEVER revokes or replaces another session (no `LOGIN_REPLACED` for ordinary logins). When the account already has three active sessions, a fourth login is rejected with `SESSION_LIMIT_REACHED` and a clear message that the user must log out of one existing device first; nothing is terminated automatically. The password is verified BEFORE this answer, so it discloses nothing to someone who does not know the password. The limit holds under simultaneous logins (database-level guarantee).

-   A session ends when it is logged out, revoked, or when its 30-day refresh token expires (`SESSION_EXPIRED`); expired sessions stop counting and are revoked at login and by a periodic job. Every revocation publishes `AuthSessionRevoked`.

-   Logout revokes only the current session. Logout all, account deactivation (§22) and password reset (§26) keep revoking all of the account's sessions. Changing the password through `POST /auth/change-password` keeps the calling session and revokes every OTHER session (`PASSWORD_CHANGED`).

-   **My Devices:** the authenticated user can list their own active sessions with safe device information (a coarse "browser on system" label derived from the User-Agent at login, creation time, last token issue time, expiry, and whether it is the current one) and revoke one selected session (`DEVICE_REVOKED`); the others stay active. No token or secret is ever exposed.

* * *

# 26\. FORGOT PASSWORD / OTP

Flow:

```plaintext
Phone
↓
Recovery Request
↓
OTP
↓
Verify
↓
New Password
```

Prevent account enumeration.

OTP:

```plaintext
6 digits
5 minutes validity
5 wrong attempts maximum
3 resends per hour maximum
5 OTP requests per 15 minutes per phone/IP combination
```

Every resend:

```plaintext
invalidate previous OTP
create new OTP
```

Successful password reset revokes existing sessions.

Never log:

-   plaintext OTP

-   plaintext refresh token

-   password

-   secrets

* * *

# 27\. ORGANIZATION / GEOGRAPHY

Hierarchy:

```plaintext
Country
↓
Governorate
↓
Center / City
↓
Village
↓
School
```

Geography is master data.

Used geography records must not be casually hard-deleted.

Organizations (approved amendment, replaces the earlier "one Main Organization" assumption):

-   Organization creation is its own workflow and endpoint, independent of school creation. An Organization exists before any School; no Main School is required and no placeholder is created. Every School belongs to an existing Organization.

-   Organization data: name (required, unique across the whole system), country (required, a registered Country), its own address (Governorate required, a registered, active Governorate of the chosen country; Center / City and Village are FREE TEXT, optional, a Village only with a Center; no registered center or village record is ever required), and the applicant (name and phone) who becomes its manager.

-   The applicant's account follows the IAM rules (phone normalized to E.164; an existing phone is a conflict, never a reuse by phone alone). The applicant receives the ORGANIZATION_MANAGER role scoped exclusively to that Organization (never MAIN_ADMIN): the role alone never grants access to another Organization's data; the organization manager link does.

-   The Organization's country is assigned at creation and is immutable (it cannot change while schools exist).

Country of a School (approved invariant):

-   Every School has the same country as its Organization. The country is derived from the Organization on the server; a client-supplied country is only compared, never used. It is enforced in the application and by the database.

-   Each School keeps its own address (Governorate, Center / City, Village) anywhere inside that country; only the country is shared.

-   A user never enters a country as part of a Parent Address; it is the country of the parent's Organization.

* * *

# 28\. UNIFIED ADDRESS

Format:

```plaintext
Governorate / Center or City / Village
```

Rules:

-   Governorate required.

-   Center optional.

-   Village optional.

-   Village cannot exist without Center.

Parent Address (approved amendment):

-   Stored in three separate fields, never as one combined string: Governorate, Center / City, Village.

-   Governorate: must be a registered Governorate of the country of the parent's Organization (stored as its id) and must be active when a Parent Address is created or changed.

-   Center / City: optional free text. It does not need to be registered in the geography tables.

-   Village: optional free text. It does not need to be registered in the geography tables. A Village cannot be provided without a Center / City.

-   Whitespace is trimmed and normalized (Unicode NFC, runs of whitespace collapsed). Each free-text field has at most 200 characters. A missing optional part is stored as NULL.

-   An address is never rejected because its Center / City or Village is not registered.

-   Address history stays auditable: a change keeps the previous address, including the Governorate name as it was at the time. A historical address stays readable even if its Governorate later becomes inactive.

-   Raw text (for example an Excel cell) uses `Governorate / Center or City / Village`: `/` is the only separator, the Governorate name must match a registered Governorate exactly (after trimming and collapsing whitespace; no automatic Arabic letter normalization), empty components (`A//C`, `A/B/`, `/A`) are rejected, and `A` and `A/B` are valid. It goes through the same validation as any other Parent Address.

School Address (unchanged): schools keep the structured hierarchy validation above (registered Governorate, Center / City and Village, Village only under its Center). These Parent Address rules do not change it.

Student address is derived from the Parent.

Pipeline:

```plaintext
Raw
↓
Parse
↓
Normalize
↓
Validate Hierarchy
↓
Structured
↓
Persist
```

* * *

# 29\. SCHOOL

A School belongs directly to an existing Organization (approved amendment). There is NO Main School / Sub-School classification and no required "main" school or parent-school relationship.

Address: the country is the Organization's country; the Governorate is a registered, active Governorate of that country; Center / City and Village are free text (same contract as the Parent address).

Statuses:

```plaintext
PENDING
ACTIVE
INACTIVE
REJECTED
```

School code example:

```plaintext
SC-000001
```

Internal technical identifier should be UUID.

* * *

# 30\. SCHOOL CREATION

School creation includes:

-   school name

-   administrative address (registered governorate, free-text center and village)

-   physical GPS

-   organization (country inherited from it)

-   creator account (an Organization Manager, or the applicant of a public submission)

-   the School Manager relationship (the applicant becomes the School Manager on approval; otherwise the Organization Manager assigns one after approval)

Every newly created school starts PENDING. A school can never be ACTIVE before it is approved by the Organization Manager of the owning Organization.

GPS at creation becomes the official school center.

After approval:

```plaintext
Official GPS = immutable
```

No school move workflow exists in V1.

Geofence:

```plaintext
50 meters
```

GPS accuracy maximum:

```plaintext
20 meters
```

* * *

# 31\. SCHOOL APPROVAL WORKFLOW

```plaintext
PENDING
↓
Organization Manager of the owning Organization
├── APPROVE
└── REJECT
```

An Organization Manager cannot approve or reject a school of another Organization.

Rejection requires reason and notification.

Approval activates/creates the school account and School Manager according to the approved workflow.

* * *

# 32\. PARENT

Parent is User-based.

School Manager creates/reuses:

```plaintext
User
↓
Parent Role
↓
Parent Entity
```

Required:

-   three-part name

-   phone

-   Parent Address (Governorate / Center or City / Village, see section 28)

One Parent can have multiple children.

Parent identity is globally reusable across schools.

**Approved amendment (Module 17), business rules:**

-   Personal name: the person who creates an Organization, the person who submits a School creation request (the School Manager account created or resolved through it) and the Parent each give a personal name of EXACTLY three non-empty parts (two or four parts are invalid). It is stored once, as the canonical name of the User account, and is shared by every role of that account. It is not the Organization's or the School's name.
-   One person is one User account (one normalized phone number) even when they hold several permitted roles (for example ORGANIZATION_MANAGER + SCHOOL_MANAGER, or + PARENT). Adding a role never creates another account, never changes the password or other security state, and never widens the scope of another role.
-   In V1 "globally reusable" means reusable across the schools of the SAME organization, with a separate Parent-to-School relationship per school; a Parent account is never reused across different organizations.
-   A phone number identifies one account. When it already exists, the account is reused only if its stored three-part name equals the submitted Parent name (the approved matching criterion; it is not independent proof of identity); a missing or different stored name is an identity conflict. Accounts are never merged, and an existing account's name, password and security state are never overwritten. Parent National ID is not required.
-   A School Manager creates and reads/lists/updates Parents linked to their own school only; ORGANIZATION_MANAGER and MAIN_ADMIN have no Parent permission from their role; a Parent reads only their own profile in V1.
-   Removing a school relationship never deletes the account or affects other schools; a Parent who still has students in a school cannot be unlinked from it. Global Parent deactivation/deletion is not available while decision D-3 is open.

**Implementation constraints (not business rules):** the Parent's name cannot be edited through the Parents API because no account-level name-correction workflow exists yet; the "has students" check is a guard that Module 19 (Students) must supply (until then no student can exist); accounts created before the canonical name existed have no name until it is filled (see `docs/PARENTS.md`). See `docs/PARENTS.md` for details.

* * *

# 33\. TEACHER

Teacher is User-based.

Structure:

```plaintext
User
+
Teacher Entity
+
Teacher Role
+
School Assignment
```

Teacher can belong to multiple schools.

Teacher can teach multiple groups.

Each group:

```plaintext
maximum one teacher
```

Teacher may temporarily have no group.

Teacher is NOT automatically School Manager.

Removing Teacher from a school removes only that school relationship.

Global teacher deactivation blocks teaching actions across schools but preserves history.

**Approved amendment (Module 18), business rules:**

-   Teacher initial password: when registering a Teacher who requires a NEW User account, the initial password is the last four digits of the normalized phone number and the account-level `mustChangePassword` flag is set. The Teacher must change the password before normal protected API use; until then only the minimum authentication/session operations needed to change the password and log out are allowed (the same mechanism as for Parents, enforced by the backend). The password is only ever stored hashed and is never logged or returned.
-   Existing account: when the phone matches an existing User and the identity matches, the account is reused and receives the TEACHER role and the school relationship. The password is never reset and `mustChangePassword` is never set, cleared or otherwise modified by role assignment; the account's security state is preserved.
-   Identity: the Teacher's personal name is exactly three parts and is the account's canonical stored name. A missing or different stored name is `TEACHER_IDENTITY_CONFLICT`; the existing name is never overwritten and accounts are never merged. A matching name is the approved matching criterion, not independent proof of identity.

**Approved amendment (Module 18, confirmed by the project owner on 2026-10-31), business rules:**

-   SCHOOL_MANAGER manages the Teachers of their own school (register, list, read, remove the school link), within the approved permissions and school scope. ORGANIZATION_MANAGER and MAIN_ADMIN have no Teacher permission from their role. A Teacher reads only their own profile. No personal data other than the three-part name and the phone is collected.

-   An existing Teacher added to another school of the SAME organization reuses the existing account (no duplicate account). A Parent record of the same account must belong to that organization too.

-   Identity matching uses the phone number and the full name. A matching phone with a conflicting name is never merged automatically; it is an explicit identity conflict.

-   Historical Teacher-to-Group assignments are preserved; reassignment follows the approved group rules. A school link cannot be removed while the Teacher has ACTIVE groups in that school.

-   Hard deletion of a Teacher account is not allowed; the account lifecycle / deactivation mechanism is used and history is preserved.

-   One account may be linked to several schools of the same organization; permissions and data access stay scoped to the relevant school.

-   A deactivated Teacher cannot log in or perform new operations that need an active account. Historical records and completed sessions stay intact. Existing group assignments are handled without destroying historical relationships. (Approved behaviour; its implementation waits for decision D-3, see `docs/TEACHERS.md`.)

-   The same person may hold both PARENT and TEACHER on one account and one phone number; role permissions stay separate and active-role selection follows the existing RBAC rules.

* * *

# 34\. TEACHER PHONE / PARENT PHONE COLLISION

If:

```plaintext
Teacher Phone == Parent Phone
```

and identity is the same:

```plaintext
Reuse the same User
Assign both roles
```

Do NOT create duplicate Users.

If identity conflicts:

```plaintext
Conflict
```

Never automatically merge.

* * *

# 35\. TEACHER SCHEDULE CONFLICT

Teacher schedule conflicts are checked globally across all schools assigned to that Teacher.

Example:

```plaintext
18:00–19:00
vs
18:30–19:30
```

Conflict.

But:

```plaintext
18:00–19:00
vs
19:00–20:00
```

No conflict.

* * *

# 36\. STUDENT

Student is NOT a User in V1.

Fields include:

-   Full Name

-   National ID

-   Parent

-   School

-   Group

-   Join Date

Exactly one Parent.

Group is optional.

One student can be assigned to only one group at a time.

Student can be unassigned.

* * *

# 37\. STUDENT NAME RULES

Student name must contain at least 3 parts.

Second name:

```plaintext
Parent First Name
```

Third name:

```plaintext
Parent Second Name
```

Normalize:

-   trim

-   collapse extra spaces

Student has no independent address.

Student current address is derived from Parent.

When Parent address changes:

```plaintext
linked students' current derived address changes
```

Historical information remains auditable.

* * *

# 38\. NATIONAL ID

National ID:

-   required

-   Egyptian

-   exactly 14 digits

National ID is the trusted Student identifier during Excel import.

Duplicate National ID in the same import:

```plaintext
Conflict
```

Existing student with different Parent:

```plaintext
Identity/Data Conflict
```

Never automatically move or replace the student.

School transfer is NOT supported in V1.

* * *

# 39\. STUDENT LIFECYCLE

Students with meaningful history should be:

-   deactivated

-   archived

rather than destructively deleted.

Group deletion/archive:

```plaintext
Students → Unassigned
```

Students are never deleted because of group deletion.

* * *

# 40\. GROUPS

Group belongs to exactly one School.

Fields include:

-   Group Name

-   Teacher

-   Students

-   Schedule

-   Learning Mode

-   Progression Direction

-   Starting Surah

Group name unique within the same School only.

Maximum one Teacher.

Teacher can teach multiple Groups.

* * *

# 41\. LEARNING MODE

Allowed:

```plaintext
GROUP
INDIVIDUAL
```

GROUP:

```plaintext
same session assignment
```

INDIVIDUAL:

```plaintext
student-specific assignment
```

Changing mode must NOT rewrite history.

New mode applies forward.

* * *

# 42\. PROGRESSION

Allowed:

```plaintext
FORWARD
BACKWARD
```

Changing progression affects new assignments only.

Historical assignments retain their original direction.

* * *

# 43\. STARTING SURAH

Starting Surah is required.

* * *

# 44\. GROUP SCHEDULE

Schedule is optional during configuration/import.

Structure:

```plaintext
Day of Week
Start Time
End Time
```

Multiple recurring schedule slots are allowed, subject to the approved amendment below.

No overlapping teacher schedules.

Exact boundaries do not overlap.

**Approved amendment (Module 23, final, confirmed by the project owner on 2026-10-31):** a Group may have at most ONE schedule slot per weekday, whatever the times (so at most one session per day); different weekdays may have different slots. This decision is final and is not reopened.

* * *

# 45\. SESSION

Critical invariant:

> NO GROUP SCHEDULE = NO SESSION.

Sessions cannot be:

-   ad-hoc

-   manual

-   unscheduled

-   special

Session belongs to:

-   School

-   Group

-   Teacher

-   Group Schedule

-   Date/Time

Session lifecycle:

```plaintext
SCHEDULED
↓
OPEN
↓
IN_PROGRESS
↓
COMPLETED
```

or:

```plaintext
CANCELLED
```

Session time is derived from Group Schedule.

Teacher protected action window:

```plaintext
Session Start - 15 minutes
through
Session End
```

* * *

# 46\. QURAN STRUCTURE

Quran reference data contains:

-   Surahs

-   Ayahs

-   Pages/Faces

-   Lines

-   Juz

-   Hizb

-   Quarters

Canonical Quran ordering must support:

-   Surah

-   Ayah

-   Page/Face

-   Line

-   Quarter

-   global position

* * *

# 47\. QURAN RANGE ENGINE

Input:

```plaintext
Start Position
+
Unit
+
Amount
+
Direction
```

Units:

```plaintext
Ayahs
Lines
Pages/Faces
Quarters
```

Amount:

```plaintext
positive integer
```

Output:

```plaintext
End Position
+
Generated Range
```

Ranges may cross Surahs.

Direction:

```plaintext
FORWARD
BACKWARD
```

The engine must be deterministic and independently testable.

* * *

# 48\. MEMORIZATION

Memorization is separate from Revision.

Input:

```plaintext
Start
Unit
Amount
Direction
```

System calculates:

```plaintext
End
Range
```

A session may contain multiple valid memorization records.

Historical context must remain unchanged.

**Approved amendment (Module 27, confirmed by the project owner on 2026-10-31), business rules:**

-   **Who records.** Only the Teacher assigned to the group/session may record students' memorization. Recording goes through Smart Guard with GPS validation (§50). A School Manager cannot record on behalf of a Teacher.

-   **Scheduled assignment.** A memorization assignment is scheduled only when it was explicitly defined before the target session starts; no session is assumed to include memorization. The assigned group Teacher defines the assignment of the NEXT session DURING the current session, and may modify or cancel it only while the current session is still in progress. When the current session ends the assignment is final and immutable. The history of the changes made in the permitted period is preserved.

-   **Group type (Module 20).** Collective group: ONE shared assignment for the whole group; no separate assignments for individual students; the Teacher may repeat the same assignment for the whole group or define a new shared one. Individual group: each student has an independent assignment and different students may receive different ranges, according to each student's recitation.

-   **Assignment and performance.** A student is evaluated against the assignment defined for them or for their group; a different range cannot be recorded as fulfilment of the assignment. If a student does not memorize the complete assigned range, the ENTIRE original assignment is repeated for that student in the next session (never only the unfinished part). The scheduled assignment and the actual memorization record stay distinct.

-   **Continuity.** The assignment stays available for the next actual session of the group. If the target session is cancelled the assignment is kept and carried forward; if it is rescheduled it is carried forward according to the updated group schedule; if the Teacher is absent from the target session it is carried forward unchanged to the next actual session. It is never discarded or reset because of cancellation, rescheduling or Teacher absence, and the assigned range is preserved.

-   **Read permissions (strict school and relationship scope).** The assigned Teacher reads the records of their sessions; the School Manager reads the records within their own school; a Parent reads only the records of their own linked children; a Student has no direct read access in this module.

-   **Overlap.** Overlapping memorization ranges are allowed, including ranges previously recorded for the same student; a student may memorize the same verses again in different sessions. Every record is independent and historical records are never overwritten or deleted because of an overlap.

-   **Corrections.** The assigned Teacher may correct a memorization record only during the same session in which it was created; after that session ends the record is immutable. Records are never permanently deleted; the original record and the correction history are preserved and nothing is silently overwritten. A School Manager cannot correct on behalf of the Teacher.

* * *

# 49\. REVISION

Revision uses the same Quran range engine.

Supported forms:

```plaintext
Start + Unit + Amount
```

or:

```plaintext
From Surah X
to Surah Y
```

Historical context must remain preserved.

* * *

**Approved amendment (Module 28, confirmed by the project owner on 2026-11-01), business rules:**

-   **Same rules as Memorization.** Revision follows the approved Module 27 rules (§48 amendment): the assignment of the NEXT session defined by the session's Teacher during the current session and changeable only while it is in progress, then final with its history kept; carried forward unchanged when the target session is cancelled, rescheduled or the Teacher is absent; one shared assignment for a collective group and one assignment per student for an individual group; an incomplete revision repeats the ENTIRE original assigned range in the next applicable session; only the assigned Teacher records, through Smart Guard, and a School Manager cannot record on a Teacher's behalf; same recording, correction (same session only), immutability and audit-history rules; records are never permanently deleted; the same read permissions (assigned Teacher: their sessions; School Manager: their school; Parent: their own linked children only; Student: none); a revision record may exist even when no revision assignment was scheduled. Overlapping ranges are allowed.

-   **Range selection, form A (Start + Unit + Amount).** The meaning of the start number depends on the unit: AYAHS: the ayah number within the selected surah (the surah is required); PAGES: the Mushaf page number; QUARTERS: the Quran quarter number; SURAHS: the surah number in Mushaf order. No separate surah is selected for pages, quarters and surahs. The amount determines the range according to the unit.

-   **Range selection, form B (From Surah X to Surah Y).** Complete surahs, both the starting and the ending surah included; forward and backward are both supported; the number of surahs is inclusive of both ends. It is represented through the existing Quran Range Engine as start = the starting surah, unit = SURAHS, amount = the inclusive number of surahs. Module 22's behaviour is not changed for Module 28.


# 50\. SMART GUARD

Protected Teacher actions must validate:

```plaintext
Authentication
↓
Permission
↓
Scope
↓
Ownership
↓
Correct Time
↓
Distance
↓
GPS Accuracy
↓
Business Rules
↓
ALLOW
```

Distance:

```plaintext
<= 50m
```

GPS accuracy:

```plaintext
<= 20m
```

If GPS is:

-   unavailable

-   denied

-   missing

-   invalid

-   inaccurate

then:

```plaintext
REJECT
```

No:

-   IP fallback

-   manual location

-   postal fallback

**Approved amendment (Module 29, 2026-11-02):** the time window above is unchanged for every protected operation. The ONLY exception is Module 29 (Evaluations), which may keep the window open up to 15 minutes after the scheduled session end to record MISSING evaluations (§52); ownership, GPS, distance, accuracy and the cancelled-session check all still apply in those minutes.

**Approved amendment (Module 30, 2026-11-02):** exam result recording is a protected action that is not a session occurrence. Module 25 provides an additive exam-compatible entry point, `checkProtectedAction`: the protected module (Exams) verifies that the caller is an examiner currently assigned to that exam and supplies the time window (15 minutes before the scheduled start through the effective end, with no upper bound when the exam has no end time); Smart Guard validates the window, the GPS reading, the 50 m school geofence, the 20 m accuracy and that the school is active, with the same error codes. `check` (sessions) is unchanged.

* * *

# 51\. ATTENDANCE

Statuses:

```plaintext
PRESENT
ABSENT
```

Unique:

```plaintext
Session + Student
Session + Teacher
```

Teacher may correct attendance during the same Session according to permissions.

School Manager may correct according to permissions.

Every correction must be audited.

History must never be silently overwritten.

* * *

# 52\. EVALUATIONS

Categories:

```plaintext
Memorization
Revision
Performance
Tajweed / Rules
```

Score:

```plaintext
0.00–10.00
```

Two decimal places.

Notes optional.

After Session completion:

```plaintext
Immutable
```

Authorized corrections require:

```plaintext
Authorization
+
Audit
```

**Approved amendment (Module 29, approved by the project owner on 2026-11-02; this amendment SUPERSEDES the paragraphs above wherever they conflict, which are kept as the original record):**

1.  **Ownership.** Only the Teacher assigned to the session creates or modifies evaluations, through Smart Guard (GPS). The School Manager cannot create, modify or correct evaluations. There is NO correction workflow and NO correction permission. The Organization Manager and the Governorate, Center and Village Managers read evaluation information through the future Reports module (not directly in Module 29); Main Admin has no direct evaluation permission; a Student has no login and no access.
2.  **Reads.** The Teacher reads the evaluations of sessions assigned to them only. The School Manager reads the evaluations (grades and Teacher notes) of all students of their own school. A Parent reads the evaluations (grades and Teacher notes) of their own linked children only, and never sees historical values or modification details.
3.  **Based on assignments.** An evaluation is available only for a student with an applicable Memorization assignment (Module 27), Revision assignment (Module 28), or both. The EXISTENCE of the assignment is enough; an execution record is NOT required. Categories: Memorization only gives Memorization, Performance, Tajweed; Revision only gives Revision, Performance, Tajweed; both give all four; neither gives none. Each available category has its own independent score out of 10; Performance and Tajweed appear once each. The Memorization score is associated with the applicable Memorization assignment, the Revision score with the applicable Revision assignment, Performance and Tajweed with the applicable assignment context. Evaluation is per student, also in collective groups (no shared group score).
4.  **Attendance consistency (cross-module invariant, Modules 26 and 29).** A student marked ABSENT cannot receive an evaluation for the session. If an evaluation has been recorded for a student, marking that student ABSENT for the same session is rejected. A student with an assignment who is present must be evaluated; a student without an assignment need not be; ABSENT students are exempt; unmarked attendance is never interpreted as ABSENT. Enforced at the service and database transaction level, also for concurrent requests.
5.  **Scores and note.** Each score is from 0.00 to 10.00 and is ROUNDED to two decimal places (not rejected). One optional Teacher note per student's evaluation for the session, shared by all categories, at most 200 characters, never editable or deletable once saved. Scores can be modified only within the permitted window. Previous score and note values are NOT retained, and NO modification history and NO audit history of score changes is kept (this supersedes the audit requirement above for evaluation modifications).
6.  **Time windows.** The session lifecycle remains owned by Module 24. Before and during the scheduled session the assigned Teacher records evaluations through Smart Guard and GPS and may modify previously recorded scores while the session is in progress; no evaluation for a cancelled session. Exactly 15 minutes before the scheduled end, the Teacher is warned (through the future Notifications modules) when present students with assignments still lack a required evaluation. A session becomes COMPLETED automatically at its scheduled end (Module 24); Module 29 then has a 15-minute grace period after the scheduled end in which the assigned Teacher may record MISSING evaluations only (Smart Guard and GPS remain mandatory; no score, note or existing evaluation can change and no duplicate can be created). After the grace period every evaluation write is permanently closed. The grace period is computed from the actual scheduled session end (the Africa/Cairo schedule computed by Module 24), never from processing time. Smart Guard's general window (§50) is NOT extended for any other module or operation: the post-end minutes are a narrow, explicit exception used by Module 29 only.
7.  **Parent notifications.** Delivery belongs to the Notifications modules. Module 29 publishes the integration events (EvaluationRecorded: grades and the Teacher note when one exists; EvaluationScoresUpdated: the updated grades, on every score modification in the permitted window). No note-edit notification exists (the note is immutable); historical values are never exposed.
8.  **Missing evaluations.** Missing evaluations never prevent Module 24 from completing the session. After the grace period they remain unrecorded: no default score, no zero score and no fabricated record is ever created.

* * *

# 53\. EXAMS

There is NO restriction of one exam per month.

School Manager may create any number of exams at any time.

Target:

-   one Group

-   multiple Groups

-   whole School

Fields:

-   Date

-   Start Time

-   optional End Time

-   target Groups

-   whole-school option

-   examiners

Examiner:

-   must be Teacher

-   must belong to same School

-   may differ from Group Teacher

-   multiple examiners allowed

Manager may change examiner assignments after start according to permissions.

Completed results remain unchanged.

* * *

# 54\. EXAM LIFECYCLE

```plaintext
DRAFT
↓
SCHEDULED
↓
STARTED
↓
COMPLETED
```

or:

```plaintext
CANCELLED
```

Draft/scheduled can be cancelled.

Started cancellation requires special Manager permission.

Completed cannot be cancelled.

* * *

# 55\. EXAM QUESTIONS

Exam defines:

```plaintext
Question Count
Max Score per Question
```

Examiner enters score per question.

Validation:

```plaintext
0 <= score <= max score
```

System calculates total.

Examiner sees only students not yet examined.

After result completion:

```plaintext
student removed from pending
```

* * *

# 56\. EXAM RESULT IMMUTABILITY

Before completion:

```plaintext
Authorized changes allowed
```

After completion:

```plaintext
Immutable
```

Correction requires:

```plaintext
Authorization
+
Audit
```

* * *

# 57\. EXAM NOTIFICATIONS

Required:

-   examiner assignment

-   exam created/assigned to parents

-   result immediately

-   reminder 24 hours before

**Approved amendment (Module 30, approved by the project owner on 2026-11-02; it SUPERSEDES §53-57 above wherever they conflict, which are kept as the original record):**

1.  **Lifecycle.** `DRAFT -> SCHEDULED -> STARTED -> COMPLETED -> ENDED`, plus `CANCELLED`. The School Manager creates any number of exams at any time (DRAFT) and schedules them. A SCHEDULED exam becomes STARTED automatically at its scheduled start time (Africa/Cairo). If an end time is defined it becomes COMPLETED automatically at the effective end time; with no end time the School Manager completes it manually. ENDED is a SEPARATE, manual, final closure that is only possible after COMPLETED and never happens automatically.
2.  **Cancellation and deletion** are separate operations and both are allowed ONLY before STARTED (DRAFT or SCHEDULED). An exam cannot be cancelled after it started, whatever the permission (this supersedes §54's "cancellation after start with a special Manager permission"). An exam cannot be deleted after STARTED. (Deletion keeps the record and hides the exam from every read.)
3.  **Editing.** Before STARTED the School Manager can change all exam data: start and end date/times, question count, maximum score per question, target groups, examiners and the other configuration. After STARTED the start time is immutable and the question count, maximum score and targets are locked; the end time remains editable (extended or reduced) but a new end time must be strictly in the future at the moment of the update, and the updated end time decides the automatic completion. After COMPLETED or ENDED nothing about scheduling or configuration can change, except the COMPLETED -> ENDED action.
4.  **Targets.** One group, several groups, or the entire school (every student who currently belongs to a group of the school). Before STARTED the target student list stays synchronized with the current group membership (add, remove, move, and a change of the targeted groups rebuilds it). At STARTED it is frozen: students who leave a targeted group stay in the exam, students who join are not added, and group membership changes never affect the frozen list.
5.  **Examiner workflow.** For exams targeting several groups or the whole school, students are shown separated by group: the examiner selects a group, then sees its PENDING students (never one flat list). Several examiners can be assigned; any assigned examiner can examine any pending student of any targeted group. Of two concurrent submissions for the same student the first atomic transaction wins; no duplicate result exists. An examined student leaves the pending list.
6.  **Examiners and permissions.** Examiners are Teachers registered in the exam's school (a Teacher of another school is not eligible, even in the same organization); a School Manager can be an examiner only if registered as a Teacher in that school. Only currently assigned examiners can submit results. The School Manager can add or remove examiners until the exam is ENDED, also after STARTED; removing an examiner does not affect results already recorded. The examiner permission (the approved "TESTER" permission) is scoped to the specific exam and never creates, removes or changes the user's TEACHER role or any other role. At ENDED it is removed from every examiner of the exam; all records and results are preserved.
7.  **Questions and scoring.** The School Manager defines the question count and ONE uniform maximum score applied to every question; both are fixed at scheduling and cannot change after STARTED. Each question score satisfies `0 <= score <= maximum`, is rounded to two decimal places (consistently with Module 29), and the total is the sum of the question scores. There is no pass mark, percentage, ranking or pass/fail classification.
8.  **Results.** The examiner submits all question scores of one student in one atomic operation (no partial persistence); a student has one result per exam. Results are immutable once recorded: no user, including the School Manager or any higher-level administrator, can edit or delete an exam result under any circumstances (this supersedes §56's "authorized corrections with authorization and audit": there is NO correction workflow, and no audit/history of result changes exists because results never change).
9.  **Absence.** When the exam reaches COMPLETED every targeted student without a recorded result is automatically marked ABSENT. No score and no result with zero scores is ever created for an absent student. No score can be submitted after COMPLETED, and the end time cannot be extended or the submission reopened once COMPLETED. While the exam is still STARTED the School Manager can move the end time to a future time.
10. **COMPLETED and ENDED are different.** COMPLETED: the effective end was reached, missing students are ABSENT, new results cannot be submitted, existing results are immutable, and the examiners' exam-scoped permission stays active (subject to the restrictions above) until ENDED. ENDED: the final closure by the School Manager (only after COMPLETED, never automatic); all exam data and operations become permanently locked, the exam-scoped examiner permission is removed from all of the exam's examiners, and all records and results are preserved.
11. **Smart Guard.** Recording a result requires Smart Guard and GPS verification, only for an examiner assigned to that exam, with the approved school geofence rules. The exam-specific time window starts 15 minutes before the scheduled start and continues through the effective end time. An exam is not a session occurrence: Module 25 gains an additive exam-compatible entry point (`checkProtectedAction`) and its behavior for every other module is unchanged. Results can in any case only be recorded while the exam is STARTED.
12. **Reads.** School Manager: all exams and all recorded results of their school. Assigned examiner: the exams they are currently assigned to and the pending students list (with each student's group and examination status), never any recorded result (not even their own); they lose all exam-scoped access at ENDED. Parent: the exam schedule relevant to their children's school, and only their own linked children's recorded results and ABSENT status. A Teacher who is not an assigned examiner and a Student (no login): no direct access. Organization and geographic managers: through the future Reports module only.
13. **Notifications** (delivery belongs to the Notifications modules 31-34; Module 30 only publishes events and reads): examiner assignment, exam creation/assignment to parents (on scheduling and when a student is added to a targeted group before the exam starts), the result immediately after it is recorded, and the 24-hour reminder (`ExamService.getExamReminderStatus`). Details: docs/EXAMS.md.

* * *

# 58\. SUBSCRIPTIONS

Subscription represents:

```plaintext
Student + Month
```

Statuses:

```plaintext
PAID
UNPAID
WAIVED
```

Multiple unpaid months are allowed.

New student subscription amount is determined outside the system.

The system tracks only:

-   paid

-   unpaid

-   waived

No prorating.

* * *

**Approved amendment (Module 33), business rules (approved 2026-11-07 and 2026-11-08; implementation details are in `docs/SUBSCRIPTIONS.md`):**

1. **Monthly creation is manual and bulk, per school.** The School Manager or a Subscription Collector of the school starts it. The system takes the current month in `Africa/Cairo`. If the school already has that month, the user is told and nothing is duplicated. Otherwise one UNPAID subscription is created for every regular (ACTIVE) student of the school. Student + Month is unique. A student who joins after the bulk creation may get an individual subscription for the same month (also duplicate-protected) without affecting other students.
2. **A subscription is only Student + Month + Status (PAID / UNPAID / WAIVED).** There are no fee calculations, prorated payments, partial-month rules or charges based on enrollment dates.
3. **Subscription Collectors (Option A).** The Collector-to-School assignment is a Module 33 relationship with history. The School Manager assigns and unassigns Collectors for their own school and may create a Collector account with the Teacher account conventions (initial password = the last four normalized digits of the phone; existing eligible accounts are reused without duplicates). A Collector may serve several schools of the same organization and accesses subscription data only for schools they are currently assigned to; historical assignments grant nothing.
4. **Payments.** Module 33 owns subscription records, statuses and the Oldest-Unpaid Rule and exposes a `markPaid` application contract and a `SubscriptionPaid` event. Module 34 calls the contract when a payment is recorded. Module 33 has no public endpoint that marks a subscription PAID.
5. **Notifications** (through the Notifications infrastructure only): (A) bulk creation → Subscription Collector; (B) payment recorded → Parent only; (C) first unpaid reminder 3 calendar days after creation (Africa/Cairo; status checked first; only if still UNPAID; Parent only); (D) end-of-month unpaid reminder once per school and month at the beginning of the final five calendar days of the month (26th in a 30-day month, 27th in a 31-day month, February by its actual length) → each unpaid student's Parent (own child), the Subscription Collector(s) and the School Manager (the students who remain unpaid); PAID and WAIVED are excluded, nothing is sent when no student remains unpaid, and no duplicates are sent.

# 59\. OLDEST UNPAID RULE

A newer month cannot be paid until all older months are:

```plaintext
PAID
or
WAIVED
```

No partial payments.

* * *

# 60\. PAYMENTS

Payment method:

```plaintext
CASH ONLY
```

Payment belongs to:

```plaintext
Student
+
School
+
Subscription
```

One successful payment per subscription.

Successful payment must never be hard-deleted.

Reversal requires:

-   reason

-   actor

-   timestamp

-   audit

* * *

# 61\. COLLECTION

Allowed:

-   School Manager

-   Subscription Collector

Subscription Collector:

-   assigned school scope

-   cannot waive in V1

Waiver is primarily School Manager responsibility.

* * *

# 62\. NOTIFICATIONS ARCHITECTURE

Use:

```plaintext
Business Action
↓
Domain Event
↓
Transactional Outbox
↓
Notification Service
↓
Locale Resolution
↓
Arabic / English Content
↓
Persistent Notification
↓
Realtime Delivery
```

Persistent notification is the source of truth.

Realtime failure must NOT lose notification.

Notification fields:

-   id

-   recipient

-   type

-   title

-   body

-   data

-   readAt

-   createdAt

Retention:

```plaintext
Indefinite
```

* * *

# 63\. REQUIRED NOTIFICATIONS

V1:

-   Sub-school approval

-   Sub-school rejection

-   Exam assignment

-   Exam created/assigned

-   Exam result

-   Group assignment change

-   Student assignment change

-   Exam reminder

-   Session half-time teaching reminder (approved amendment)

No competition notifications.

Session half-time teaching reminder (approved amendment):

-   A session may contain memorization, revision, both, or neither. Missing teaching records are NOT an error by themselves, and the system never creates teaching records or fabricates educational data when a session ends.

-   If memorization and/or revision were SCHEDULED for the session and the assigned Teacher has not recorded the corresponding teaching data after half of the session's scheduled duration has elapsed, a reminder is sent to the assigned Teacher only.

-   No reminder is sent for an activity that is not scheduled for that session, and none for a cancelled session.

-   "Scheduled" means explicitly defined for that session before it starts (for memorization: a specific memorization assignment, §48). A session without such a definition has no scheduled activity.

-   Missing teaching records never justify fabricating educational records or creating them automatically.

-   Modules 27 (Memorization) and 28 (Revision) must expose, through public read interfaces, which activities are scheduled for a session and which teaching records exist for it, so that the Notifications modules can decide whether a reminder is due.

-   Notification delivery belongs to the Notifications modules (31-34). Modules before them only document this requirement and preserve the integration contract (docs/ATTENDANCE.md); no notification delivery or notification infrastructure is introduced earlier.

Evaluation notifications (approved amendment, Module 29, 2026-11-02):

-   Parent: when an evaluation is first recorded, a notification with the recorded grades and the Teacher note (when one exists); on every later score modification in the permitted window, a new notification with the updated grades (grades only when there is no note). Never historical values.

-   Teacher: exactly 15 minutes before the scheduled session end, a warning when present students with an assignment still lack a required evaluation (the session is not cancelled).

-   Module 29 exposes `EvaluationService.getSessionEvaluationStatus` and the events EvaluationRecorded / EvaluationScoresUpdated for this; delivery belongs to the Notifications modules (31-34) and nothing is delivered inside Module 29 (docs/EVALUATIONS.md).

Exam notifications (approved amendment, Module 30, 2026-11-02): examiner assignment (ExamExaminerAssigned / ExamExaminerRemoved); exam created/assigned to the parents of the target students (ExamScheduled, and ExamStudentTargeted / ExamStudentUntargeted for a student who joins or leaves a targeted group before the exam starts); the result immediately after it is recorded (ExamResultRecorded, with the question scores and the total); the reminder 24 hours before the start (the read `ExamService.getExamReminderStatus`, due at `startAt - 24 h` while SCHEDULED). Delivery belongs to the Notifications modules (31-34); nothing is delivered inside Module 30 (docs/EXAMS.md).

**Approved amendment (Module 31, owner decisions of 2026-11-04 and 2026-11-05; the text above is kept as the historical record):**

-   **Channels:** only **In-App notifications** and free **Web Push** (Web Push API, Service Worker, VAPID, the Node `web-push` library, subscriptions stored in MariaDB). No SMS and no email in this scope. Push depends on browser/OS support and the user's permission; a push failure never loses the notification ("realtime delivery is not the source of truth").

-   **Account-based, not device-based:** a notification belongs to the user ACCOUNT. One record is created per recipient account and the same notifications, read state and deletions apply on every device/session of the account. A push subscription belongs to a browser/device endpoint, is linked to the account and to the authentication session that created it, and is deleted when that session ends for any reason (Module 10 `AuthSessionRevoked`); other subscriptions and the account's notifications are never touched. Invalid subscriptions (push service answers 404/410) are removed without affecting the account's other subscriptions.

-   **Account operations:** mark one as read, mark all as read, delete one, clear all. All are account-wide; ownership is enforced; another account's notifications cannot be read, changed or deleted.

-   **Hard delete:** delete and clear-all permanently remove the records (no `deleted_at`, no archive, no automatic purge, which replaces "retention: indefinite" for the account's own deletions). Deleting a notification never touches domain events, audit records or any other module's data.

-   **Once-only keys:** a ledger `notification_dedup_keys` (only `recipient_user_id`, `dedup_key`, `created_at`, no content, never exposed) is written BEFORE the notification and is never deleted, so reprocessing the same event or reminder never recreates a notification that was generated and later deleted.

-   **Language:** Arabic and English templates for every notification; the account's configured language is used when one exists, otherwise Arabic; the rendered title and body are persisted at creation and keep their original language afterwards. No account-language setting is added by Module 31.

-   **Responsibilities:** Module 31 (Notifications Core) owns storage, templates, the `notify` contract, the in-app API, push subscriptions, push delivery and cleanup. It consumes no business event. Module 32 (Notification Rules) owns the event consumers, the time-driven reminders, the recipient resolution and the once-only keys of each rule.

**Approved amendment (Module 32, owner decisions of 2026-11-07; they SUPERSEDE any conflicting text above, which is kept as the historical record):**

-   **Group changes:** `GroupStudentAssigned`, `GroupStudentUnassigned`, `GroupTeacherChanged` and `GroupArchived` notify the Teacher responsible for the group (all four, including changes affecting individual students) and, for the student-specific events, ONLY the Parent accounts linked to the affected student. A move between groups notifies those parents of the removal from the previous group and the assignment to the new one.

-   **Student assignment changes:** changing a student's memorization or revision assignment is exclusive to the responsible Group Teacher (Modules 27 and 28 unchanged). Only the Parent accounts linked to that student are notified; no unrelated parent and not the Teacher who made the change.

-   **Exam reminder 24 hours before the start:** sent to the Parent accounts of all targeted students AND all examiners currently assigned; an exam scheduled less than 24 hours before its start is reminded IMMEDIATELY (not skipped).

-   **Exam modifications:** every modification of a scheduled exam that Module 30 permits (start or end time, target groups or students, examiner assignments or removals, other modifiable configuration) and every cancellation notifies the affected parents and the currently assigned examiners as applicable, reflecting the actual change and exposing nothing about unrelated students. No notification for a change Module 30 does not permit.

-   **Delayed scheduler, half-session reminder:** if the scheduler misses the time (delay, outage, restart) the reminder is sent immediately when it resumes, provided the session is still in progress and not cancelled, memorization and/or revision was explicitly scheduled, and the required record does not exist; the assigned Group Teacher only; never for an unscheduled activity.

-   **Delayed scheduler, evaluation warning (15 minutes before the end):** if missed, sent immediately on resume provided the session is still in progress and present students still lack the required evaluation; the assigned Teacher only; not after the session ended or was cancelled, nor when no eligible student remains.

-   **Evaluation notifications:** every Parent account linked to the evaluated student is notified when an evaluation is recorded or its scores updated, with the associated assignment, the student's scores, the total and the Teacher note when one exists (omitted otherwise); never a historical or superseded value (Module 29 rules unchanged).

-   **School requests:** a submitted school creation request notifies the Organization Manager; approval or rejection notifies ONLY the original requester (with the rejection reason when rejected), and nobody else unless an approved rule requires it.

-   **Cancelled sessions and exams:** a pending time-driven reminder is cancelled or suppressed and never sent after the cancellation.

-   **Multiple Parent accounts:** whenever a rule notifies a student's parents, every Parent account currently linked to that student is notified, each only about their own linked children, with duplicate delivery to the same Parent for the same event prevented.

-   **Dependencies (Module 32):** besides 31 and 06, only public contracts of 00 (shared kernel), 13, 16, 17, 18, 19, 20, 24, 27, 28, 29 and 30; its own tables are `notification_reminders` and `notification_exam_audience`.

**Approved clarifications (Module 32, owner decisions of 2026-11-07, second review):**

-   **Group Teacher change:** BOTH the newly assigned Teacher and the previously assigned Teacher are notified.

-   **Group archiving:** unchanged: the responsible Group Teacher is notified, and each Parent account linked to a student of the archived group is notified separately.

-   **Student assignments:** both creating a new assignment and modifying an existing one notify the Parent accounts linked to the affected student; only the responsible Group Teacher may create or modify assignments (Modules 27 and 28).

-   **Assignment details:** the Parent notification includes the ACTUAL Quran range according to the assignment unit (surah and ayah range, Mushaf page range, quarter range, or surah range with both endpoints included), obtained from the existing public contracts (Modules 22, 27, 28 and the read-only Quran structure) without direct access to another module's tables or duplicated business logic.

-   **No backfill:** reminders are generated only from the normal Module 32 event and scheduling flow after deployment; no historical reminders and no delayed notifications for exams scheduled or sessions generated before the deployment.

* * *

# 64\. AUDIT / HISTORY

Audit is immutable.

**Approved amendment (Module 29, 2026-11-02):** evaluation score modifications are NOT audited and no previous evaluation value is retained (see §52). This does not authorize deleting any other historical record.

Retention:

```plaintext
Indefinite
```

Fields:

```plaintext
actorUserId
action
module
entityType
entityId
before
after
ipAddress
userAgent
timestamp
```

Important audited actions include:

-   create

-   update

-   delete

-   activate

-   deactivate

-   role changes

-   permission changes

-   approval

-   rejection

-   payment

-   waiver

-   sensitive actions

-   corrections

Never log:

-   password

-   plaintext OTP

-   plaintext refresh token

-   secrets

* * *

# 65\. HISTORICAL RULE

Historical data must NEVER be silently rewritten.

Current relationships and historical relationships must remain distinguishable.

Example:

If Student was in:

```plaintext
Group A
```

and later moved to:

```plaintext
Group B
```

reports for old periods must still show:

```plaintext
Group A
```

not Group B.

* * *

# 66\. REPORTING

Reports must use historical context.

Periods:

### This Month

```plaintext
First day of current month
→ Now
```

### Last Month

```plaintext
Previous full calendar month
```

### Across Time

All historical data within authorized scope.

### Custom

Inclusive start/end.

Internally:

```plaintext
[start, end + 1 day)
```

* * *

# 67\. STUDENT REPORT START

Student report effective start:

```plaintext
MAX(Student Join Date, Requested Report Start)
```

Never report student data before joining date.

* * *

# 68\. REPORT TYPES

Reports include:

-   Student

-   Parent

-   Group

-   Teacher

-   School

-   Geographic

-   Attendance

-   Memorization

-   Revision

-   Evaluation

-   Performance

-   Payment

Parent reports include all linked children with separate context.

* * *

# 69\. CURRENT ASSIGNMENT REPORTING

Current assignment depends on Learning Mode.

GROUP:

```plaintext
Group assignment
```

INDIVIDUAL:

```plaintext
Student-specific assignment
```

* * *

# 70\. REPORT OUTPUT

APIs / JSON are primary.

Exports are NOT automatically part of reporting.

Report export requires explicit approval.

Report export is not generic file management.

* * *

# 71\. DATE / TIME

Database timestamps:

```plaintext
UTC
```

Business/display timezone:

```plaintext
Africa/Cairo
```

This applies to:

-   sessions

-   schedules

-   reminders

-   reports

-   Smart Guards

-   business dates

* * *

# 72\. BACKGROUND JOBS

Use BullMQ + Redis where required.

Approved use cases include:

-   OTP expiration

-   monthly subscriptions

-   exam reminders

-   outbox processing

-   notification processing

Jobs must NEVER invent business behavior.

* * *

# 73\. EXCEL FILE INFRASTRUCTURE

V1 supports Excel only:

```plaintext
.xlsx
```

Maximum:

```plaintext
10 MB
10,000 rows
```

Files are private by default.

No generic:

-   PDF management

-   certificate management

unless explicitly approved later.

* * *

# 74\. EXCEL IMPORT

Import pipeline:

```plaintext
Upload
↓
Parse
↓
Normalize
↓
Address Validation
↓
National ID Matching
↓
Parent Matching
↓
Teacher Matching
↓
Group Matching
↓
Duplicate Detection
↓
Conflict Detection
↓
Business Validation
↓
Preview
↓
Explicit Confirmation
↓
Transaction
↓
Create / Reuse
↓
Relationships
↓
Commit
```

Critical error:

```plaintext
ROLLBACK
```

* * *

# 75\. EXCEL FIELDS

Required:

```plaintext
1. Student Full Name *
2. Student National ID *
3. Parent Full Name *
4. Parent Phone *
5. Parent Address *
6. Group Name *
7. Teacher Name *
8. Teacher Phone *
9. Learning Mode *
10. Progression Direction *
11. Starting Surah *
12. Group Schedule (optional)
```

Parent Address * is one cell in the format `Governorate / Center or City / Village` and follows the Parent Address rules of section 28.

There is NO Student Address column.

* * *

# 76\. EXCEL IDENTITY MATCHING

Student:

```plaintext
National ID
```

Parent:

```plaintext
Phone + Identity
```

Teacher:

```plaintext
Phone + Identity
```

Same phone + same identity:

```plaintext
Reuse
```

Same phone + different identity:

```plaintext
Conflict
```

Never silently replace.

* * *

# 77\. EXCEL CONFLICTS

Examples:

-   duplicate student ID

-   existing student with different parent

-   existing group with different teacher

-   teacher schedule overlap

-   invalid student name

-   invalid address

-   invalid learning mode

-   invalid progression direction

-   invalid starting Surah

No silent replacement.

* * *

# 78\. EXCEL PREVIEW

Preview must show:

-   new users

-   existing users

-   new students

-   existing students

-   new parents

-   existing parents

-   new teachers

-   existing teachers

-   new groups

-   warnings

-   conflicts

-   errors

User must explicitly confirm before commit.

Errors require:

-   stable error code

-   Arabic message

-   English message

* * *

# 79\. FILE ACCESS

Files are private by default.

File access must validate:

```plaintext
Authentication
+
Permission
+
Scope
+
Ownership
+
Visibility
```

No direct public file URLs for private resources.

* * *

# 80\. MODULE MAP

Implement exactly these 41 modules:

```plaintext
00 Shared Kernel
01 Configuration & Environment
02 Database & Transaction Infrastructure
03 Error & Localization
04 Validation & API Standards
05 Logging & Request Context
06 Domain Events & Transactional Outbox
07 File Infrastructure

08 Identity Core
09 Roles & Permissions
10 Sessions & JWT
11 OTP & Password Recovery
12 Authorization Engine

13 Organization Core
14 Geography
15 Unified Address
16 Schools

17 Parents
18 Teachers
19 Students

20 Groups
21 Quran Structure
22 Quran Position & Range Engine
23 Group Schedules
24 Sessions

25 Smart Guard
26 Attendance
27 Memorization
28 Revision
29 Evaluations
30 Exams

31 Notifications Core
32 Notification Rules
33 Subscriptions
34 Payments & Collection
35 History & Audit

36 Excel Import
37 Reports Core
38 Report Modules
39 File / Excel Access Control

40 Integration & E2E
```

Competition is not included.

* * *

# 81\. MODULE DEPENDENCIES

## 00

No dependencies.

## 01

Depends on 00.

## 02

Depends on 00, 01.

## 03

Depends on 00, 01.

## 04

Depends on 03.

## 05

Depends on 00, 03.

## 06

Depends on 02, 05.

## 07

Depends on 00, 01.

## 08

Depends on 02, 03, 04, 05.

## 09

Depends on 08.

## 10

Depends on 08, 09.

## 11

Depends on 08, 10, 03.

## 12

Depends on 08, 09, 10.

## 13

Depends on 02, 06.

## 14

Depends on 13.

## 15

Depends on 14.

## 16

Depends on 12, 13, 14, 15, 06.

## 17

Depends on 08, 12, 15, 16.

## 18

Depends on 08, 12, 16.

Schedule conflict ownership remains in Module 23.

## 19

Depends on 17, 16, 12.

## 20

Depends on 16, 18, 19, 12.

## 21

Depends on 02.

## 22

Depends on 21.

## 23

Depends on 18, 20, 12.

## 24

Depends on 20, 23, 22, 18, 16.

## 25

Depends on 12, 16, 23, 24.

## 26

Depends on 24, 25, 19.

## 27

Depends on 22, 24, 25.

## 28

Depends on 22, 24, 25.

## 29

Depends on 24, 27, 28, 25.

**Approved amendment (Module 29, 2026-11-02):** Module 29 also depends on 26 (Attendance, for the attendance/evaluation invariant), and on 20 (the eligible roster), 18 (the Teacher) and 16 (the School Manager) through their public contracts. Module 26 depends on Module 29 through NO import: it owns a veto port (`StudentEvaluationGuard`) that the composition root plugs in. Module 25 gains the optional, narrowly scoped `allowAfterEndMinutes` exception (at most 15 minutes) that only Module 29 uses.

## 30

Depends on 18, 19, 20, 25.

**Approved amendment (Module 30, 2026-11-02):** Module 30 also depends on 16 (the School Manager and the school), 17 (the Parent's schools), 12 (authorization) and 29 (the shared score rounding), and consumes Module 20's public events (group membership). It adds the exam-scoped examiner permission as a MANAGEMENT/EXAM scope resolver registered through the Authorization Engine (no role is created or changed) and the additive Smart Guard entry point `checkProtectedAction` (Module 25). No earlier module imports Module 30.

## 31

Depends on 06, 03.

**Amended (Module 31, 2026-11-05):** also depends on 00, 01, 02, 04 (shared kernel, configuration, database, validation/API) and 10 (`AuthSessionRevoked`, authentication), through their public contracts only.

## 32

Depends on 31, 06.

## 33

Depends on 19, 16, 12.

## 34

Depends on 33, 12, 16, 19.

## 35

Depends on 06, 05.

## 36

Depends on 07, 15, 17, 18, 19, 20, 12, 02.

## 37

Depends on 35, 12, 02.

## 38

Depends on 37, 26, 27, 28, 29, 30, 33, 34, 35.

## 39

Depends on 07, 12, 36.

## 40

Depends on all required modules for final integration.

* * *

# 82\. IMPLEMENTATION ORDER

Implement in this exact order.

## PHASE 1 — FOUNDATION

```plaintext
00
01
02
03
04
05
06
07
```

## PHASE 2 — SECURITY

```plaintext
08
09
10
11
12
```

## PHASE 3 — ORGANIZATION

```plaintext
13
14
15
16
```

## PHASE 4 — PEOPLE

```plaintext
17
18
19
```

## PHASE 5 — EDUCATIONAL STRUCTURE

```plaintext
20
21
22
23
24
```

## PHASE 6 — PROTECTED EDUCATIONAL OPERATIONS

```plaintext
25
26
27
28
29
30
```

## PHASE 7 — NOTIFICATIONS / HISTORY

```plaintext
31
32
35
```

## PHASE 8 — FINANCIAL

```plaintext
33
34
```

## PHASE 9 — IMPORT / REPORTING / FILE ACCESS

```plaintext
36
37
38
39
```

## PHASE 10 — FINAL INTEGRATION

```plaintext
40
```

* * *

# 83\. MODULE IMPLEMENTATION PROCESS

Before implementing each module, analyze:

```plaintext
1. Requirements
2. Business Logic
3. Roles
4. Permissions
5. Scope
6. Ownership
7. Validation
8. Workflow
9. Smart Guards
10. Domain Events
11. Notifications
12. Historical Rules
13. Reporting Requirements
14. Domain Model
15. Database Design
16. Application Use Cases
17. API Design
18. Implementation
19. Authorization
20. Tests
21. Documentation
```

Do not skip these because another module already exists.

Cross-module dependencies must be checked before implementation.

* * *

# 84\. MODULE COMPLETION CRITERIA

A module is NOT complete merely because its code compiles.

A module is complete only when:

-   business responsibility is implemented

-   public contracts exist where needed

-   roles are enforced

-   permissions are enforced

-   scope is enforced

-   ownership is enforced

-   validation exists

-   transactions are correct

-   domain events are correct

-   history is preserved

-   audit is implemented where required

-   localization exists

-   tests exist

-   documentation exists

-   API behavior is documented

-   module boundaries are respected

* * *

# 85\. TESTING

Every module must have appropriate:

-   Unit tests

-   Application/use-case tests

-   Integration tests

-   Authorization tests

-   Business rule tests

-   Validation tests

Critical workflows require E2E tests.

Tests must cover at least:

### IAM

-   login

-   password

-   refresh

-   logout

-   session replacement

-   OTP

-   password recovery

-   role lifecycle

-   authorization

### Organization

-   organization

-   geography

-   addresses

-   schools

-   sub-school approval/rejection

### People

-   parents

-   teachers

-   students

-   identity matching

### Education

-   groups

-   schedules

-   sessions

-   Quran range engine

-   attendance

-   memorization

-   revision

-   evaluation

-   exams

### Finance

-   subscriptions

-   oldest unpaid rule

-   payments

-   waiver

-   reversal

### Import

-   parsing

-   normalization

-   duplicates

-   conflicts

-   rollback

-   preview

-   confirmation

### Notifications

-   events

-   persistence

-   localization

-   realtime failure behavior

### Reports

-   date periods

-   historical relationships

-   scope

-   join date

### Audit

-   important actions

-   corrections

-   immutable history

Competition tests must NOT be added.

* * *

# 86\. SECURITY RULES

Never:

-   store plaintext passwords

-   store plaintext OTP

-   store plaintext refresh tokens

-   expose secrets

-   expose private files

-   trust frontend authorization

-   trust client-provided ownership

-   trust client-provided school scope

-   allow arbitrary query fields

-   allow arbitrary sorting

-   leak account existence during password recovery

-   silently merge identities

Validate every protected action on backend.

* * *

# 87\. ERROR HANDLING

Use centralized error handling.

Errors should provide:

```plaintext
errorCode
message
locale
requestId
```

Where applicable.

Business errors must use stable codes.

Do not expose:

-   SQL errors

-   stack traces

-   secrets

-   internal infrastructure details

to normal production API clients.

* * *

# 88\. API DESIGN RULES

Use:

-   RESTful resource naming

-   explicit DTOs

-   validation

-   pagination

-   sorting whitelist

-   filtering whitelist

-   standardized success responses

-   standardized error responses

Do not expose Sequelize models directly.

Do not return domain entities directly from controllers.

Use serializers / DTO mapping.

* * *

# 89\. DATABASE RULES

Use Sequelize migrations.

Do not rely on `sync({ alter: true })` as production schema management.

Use migrations for schema evolution.

Use indexes and unique constraints for true invariants where appropriate.

Database constraints should reinforce business invariants, but business logic must also be enforced at application level.

* * *

# 90\. SEED DATA

Create only necessary development/reference seed data.

Do not create fake business data unless explicitly needed for tests.

Quran reference data must be treated as authoritative project reference data.

Do not invent Quran content.

* * *

# 91\. DOCUMENTATION

Maintain:

```plaintext
docs/MASTER-SPECIFICATION.md
docs/ARCHITECTURE.md
docs/MODULE-MAP.md
docs/IMPLEMENTATION-STATUS.md
docs/PROJECT-CHANGELOG.md
README.md
```

Documentation must remain synchronized with implementation.

* * *

# 92\. PROJECT CHANGE SUMMARY

After every significant implementation change, update the Markdown project-change summary.

It must contain:

```plaintext
Architecture
Implemented Modules
Business Rules
Roles
Permissions
Scopes
Ownership
Workflows
Decisions
Database Changes
API Changes
Dependencies
Environment Changes
Constraints
Remaining Work
Tests
```

Do not allow documentation to become stale.

* * *

# 93\. MASTER SPECIFICATION CHANGE CONTROL

If a new requirement is introduced:

```plaintext
New Requirement
↓
Define
↓
Discuss
↓
Approve
↓
Update Master Specification
↓
Update Module Map if necessary
↓
Implement
↓
Test
↓
Document
```

Never implement an unapproved behavior change.

* * *

# 94\. INITIAL PROJECT BOOTSTRAP

Before implementing business modules:

1.  Create the project structure.

2.  Initialize TypeScript.

3.  Configure strict mode.

4.  Configure Node/Express.

5.  Configure Sequelize/MySQL.

6.  Configure dotenv.

7.  Configure CORS.

8.  Configure JWT dependencies.

9.  Configure bcryptjs.

10.  Configure express-validator.

11.  Configure nodemon/tsx.

12.  Configure sequelize-cli.

13.  Add BullMQ/Redis dependencies only where needed.

14.  Create environment configuration.

15.  Create `.env.example`.

16.  Create base application bootstrap.

17.  Create base HTTP server.

18.  Create health endpoint.

19.  Create module directories.

20.  Create architecture documentation.

21.  Create testing infrastructure.

22.  Make sure the server can start.

Do NOT implement module business logic during this bootstrap stage.

The bootstrap stage is architecture/setup only.

* * *

# 95\. DO NOT PREMATURELY IMPLEMENT FUTURE MODULES

Do not create fake implementations for modules that have not reached their phase.

Create their structural folders if required by the architecture, but do not invent business logic.

When a module's phase begins, implement it fully.

* * *

# 96\. CROSS-MODULE INTEGRATION

When implementing a module:

-   reuse existing public contracts

-   reuse existing events

-   reuse shared authorization infrastructure

-   reuse transaction abstraction

-   reuse localization

-   reuse request context

-   reuse audit/history mechanisms

Do not duplicate existing infrastructure.

* * *

# 97\. SELECTIVE CQRS

Use CQRS only where useful.

Good candidates:

-   Reports

-   complex read-heavy queries

-   historical aggregations

-   dashboards/read models

Do NOT create separate command/query infrastructure for every CRUD operation without justification.

* * *

# 98\. PERFORMANCE

Use appropriate:

-   database indexes

-   pagination

-   efficient queries

-   eager/lazy loading deliberately

-   batching where useful

-   background jobs for expensive asynchronous work

Avoid:

-   N+1 queries

-   unbounded queries

-   loading entire tables unnecessarily

* * *

# 99\. CODE QUALITY

Code must be:

-   TypeScript strict

-   strongly typed

-   readable

-   cohesive

-   modular

-   testable

-   maintainable

Avoid:

-   `any` unless genuinely unavoidable and documented

-   giant controllers

-   giant services

-   god classes

-   duplicated business logic

-   circular dependencies

-   hidden side effects

-   magic values

* * *

# 100\. DOMAIN LOGIC LOCATION

Business rules must live in the appropriate Domain/Application layer.

Do NOT place important business rules only inside:

-   controllers

-   Sequelize hooks

-   routes

-   frontend

-   random utility functions

Database constraints may reinforce invariants but must not be the only place a business rule exists.

* * *

# 101\. SMART GUARD OWNERSHIP

Smart Guard is reusable infrastructure.

It does NOT own:

-   attendance business logic

-   memorization business logic

-   revision business logic

-   evaluation business logic

Protected modules invoke Smart Guard before executing protected actions.

* * *

# 102\. REPORT OWNERSHIP

Reports are read models / projections over business data.

Reports are NOT the source of truth.

Business modules own business records.

Reports read them according to historical rules and authorized scope.

* * *

# 103\. HISTORY OWNERSHIP

Historical information must be available without mutating current business state.

If a relationship changes, retain:

-   previous state

-   new state

-   actor

-   timestamp

-   reason where applicable

* * *

# 104\. NO SILENT DATA LOSS

Never silently:

-   delete history

-   overwrite identity

-   merge users

-   move students

-   replace teachers

-   alter old assignments

-   alter completed exam results

-   alter completed session evaluations

-   remove payment history

If destructive behavior is not explicitly defined:

```plaintext
STOP
ASK
```

* * *

# 105\. V1 EXCLUSIONS

Do NOT implement:

-   Competition

-   Competition Manager

-   Student login

-   Student password

-   Student session

-   arbitrary ad-hoc sessions

-   school move workflow

-   generic PDF management

-   generic certificate management

-   partial payments

-   automatic identity merging

-   automatic school transfer

-   direct user-specific permissions

unless explicitly approved later.

* * *

# 106\. FINAL INTEGRATION MODULE

Module 40 is responsible for final integration and E2E verification.

It must NOT introduce new business logic.

It verifies:

-   module integration

-   authorization chains

-   event flow

-   outbox flow

-   notification flow

-   historical reporting

-   Excel import

-   financial flows

-   Smart Guard

-   session constraints

-   final API behavior

-   final security boundaries

* * *

# 107\. FINAL PROJECT QUALITY GATE

Before declaring the project complete:

### Architecture

-   no circular module dependencies

-   no private cross-module imports

-   clean architecture respected

-   module ownership respected

### Security

-   authentication works

-   authorization works

-   scope works

-   ownership works

-   sessions work

-   refresh rotation works

-   OTP limits work

-   secrets protected

### Business

-   approved rules implemented

-   no invented rules

-   no silent data mutation

### Database

-   migrations work

-   constraints work

-   indexes appropriate

-   transactions correct

### API

-   validation works

-   pagination works

-   error handling works

-   localization works

-   request IDs work

### Events

-   domain events work

-   outbox works

-   transactionality works

### Notifications

-   persistent notifications work

-   localized notifications work

-   realtime is secondary to persistence

### History

-   audit works

-   historical relationships work

### Tests

-   unit tests pass

-   integration tests pass

-   E2E tests pass

### Documentation

-   README complete

-   architecture documented

-   module map documented

-   implementation status updated

-   project changelog updated

-   master specification synchronized

* * *

# 108\. ENVIRONMENT FILE

Provide:

```plaintext
.env.example
```

It must contain placeholders only.

Never commit real credentials.

Examples of configuration categories:

```plaintext
NODE_ENV
PORT
DATABASE_HOST
DATABASE_PORT
DATABASE_NAME
DATABASE_USER
DATABASE_PASSWORD

JWT_ACCESS_SECRET
JWT_REFRESH_SECRET

REDIS_HOST
REDIS_PORT

APP_TIMEZONE
DEFAULT_LOCALE

FILE_STORAGE_PATH
MAX_FILE_SIZE
```

Use appropriate naming based on implementation.

* * *

# 109\. README

README must explain:

-   project purpose

-   architecture

-   stack

-   setup

-   environment variables

-   database setup

-   migrations

-   seeders

-   development server

-   test commands

-   build commands

-   module architecture

-   module implementation status

-   API base path

-   localization

-   background jobs

-   final project structure

* * *

# 110\. CLAUDE WORKING RULES

While implementing:

1.  Read the existing repository before changing it.

2.  Never destroy existing correct work.

3.  Never duplicate functionality unnecessarily.

4.  Check dependencies before creating code.

5.  Keep module boundaries strict.

6.  Keep business logic traceable.

7.  Keep migrations synchronized.

8.  Add tests with implementation.

9.  Update documentation with implementation.

10.  Never silently change business behavior.

11.  Never skip authorization because frontend will handle it.

12.  Never expose internal infrastructure through APIs.

13.  Never introduce a dependency without justification.

14.  Never create circular imports.

15.  Never create fake implementations simply to satisfy compilation.

16.  Never mark a module complete if its tests/business rules are incomplete.

* * *

# 111\. HOW TO HANDLE AMBIGUITY

There are two types of ambiguity.

## Technical ambiguity

You may choose a technically sound implementation.

Example:

-   internal class naming

-   repository naming

-   exact serializer implementation

-   logger library configuration

provided it does not change business behavior.

## Business ambiguity

STOP and ask.

Example:

-   who may perform an action

-   whether a record can be deleted

-   whether a status transition is allowed

-   whether historical data changes

-   whether a role gets permission

-   whether a notification is required

-   whether a workflow has an exception

Never invent these.

* * *

# 112\. IMPLEMENTATION STYLE

Implement each module completely before moving to the next phase.

For each module:

```plaintext
Analyze
↓
Design
↓
Implement
↓
Migrate
↓
Test
↓
Integrate
↓
Document
↓
Verify
↓
Mark Complete
```

Do not implement random modules out of order unless required by an explicit dependency and the user approves the deviation.

* * *

# 113\. PROJECT STATUS

Maintain:

```plaintext
docs/IMPLEMENTATION-STATUS.md
```

Each module must have a status such as:

```plaintext
NOT_STARTED
IN_PROGRESS
IMPLEMENTED
TESTED
COMPLETED
```

Do not mark a module COMPLETED until its completion criteria are satisfied.

* * *

# 114\. FINAL DELIVERY

When the entire system is complete:

1.  Run dependency installation verification.

2.  Run TypeScript typecheck.

3.  Run lint if configured.

4.  Run unit tests.

5.  Run integration tests.

6.  Run E2E tests.

7.  Run database migration verification.

8.  Verify application startup.

9.  Verify production build.

10.  Review module boundaries.

11.  Review secrets.

12.  Remove unnecessary temporary files.

13.  Do NOT include:

-   `node_modules`

-   real `.env`

-   logs

-   temporary files

-   unnecessary build artifacts

14.  Include:

-   source code

-   tests

-   migrations

-   seeders

-   docs

-   configuration

-   `.env.example`

-   README

-   package files

15.  Create:

```plaintext
Quran-School-Management-System.zip
```

The ZIP must represent the complete project.

If the environment does not support attaching the ZIP directly, create it in the project workspace and report its exact filesystem path.

* * *

# 115\. FINAL IMPORTANT INSTRUCTION

This entire document is the authoritative specification.

You are NOT allowed to:

-   invent business rules

-   remove approved rules

-   simplify approved workflows

-   change roles

-   create unauthorized roles

-   create unauthorized permissions

-   create student authentication

-   introduce Competition in V1

-   weaken backend authorization

-   bypass Smart Guard

-   rewrite history

-   silently merge identities

-   silently move students

-   silently alter completed records

-   create unscheduled sessions

-   violate module boundaries

If a required business decision is missing:

```plaintext
STOP
ASK THE USER
WAIT FOR APPROVAL
UPDATE DOCUMENTATION
THEN IMPLEMENT
```

Otherwise, proceed independently with the technical implementation.

* * *

# 116\. FIRST ACTION

When starting from an empty/new repository:

FIRST perform only the project bootstrap:

```plaintext
Create architecture
Create folders
Initialize TypeScript
Initialize Express
Configure Sequelize/MySQL
Configure environment handling
Configure base middleware
Configure request context
Configure error foundation
Configure testing foundation
Configure migration foundation
Configure health endpoint
Install required packages
Create documentation foundation
```

Do NOT implement business modules during the initial bootstrap.

After bootstrap is verified, begin:

```plaintext
MODULE 00
```

and continue according to the exact implementation order.

The final objective is a complete production-oriented Quran School Management System implemented in ONE repository, with all 41 modules integrated under the architecture and rules defined above.