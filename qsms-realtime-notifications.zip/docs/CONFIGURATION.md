# Configuration

Owned by Module 01 (`src/modules/01-configuration`). `.env` / `process.env` is read in exactly one place, `src/config/env.ts`; everything else receives a typed, validated, immutable `AppConfig`.

On any invalid value the server refuses to start and prints **all** problems at once (variable names only, never values).

| Variable | Default | Rules |
|---|---|---|
| NODE_ENV | development | development, test, production |
| PORT | 3000 | 1–65535 |
| CORS_ORIGINS | (empty = browsers denied) | comma-separated `scheme://host[:port]`; no path, no `*` |
| APP_TIMEZONE | Africa/Cairo | valid IANA timezone |
| DEFAULT_LOCALE | ar | ar, en |
| LOG_LEVEL | info (silent when NODE_ENV=test) | silent, error, warn, info, debug |
| DATABASE_HOST / PORT | 127.0.0.1 / 3306 | port 1–65535 |
| DATABASE_NAME / USER / PASSWORD | empty | **required in production** |
| JWT_ACCESS_SECRET / JWT_REFRESH_SECRET | empty | **required in production**, ≥ 32 chars, must differ |
| VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY / VAPID_SUBJECT | empty | Web Push (Module 31): all three or none; none = push disabled, in-app notifications still work. Generate with `npx web-push generate-vapid-keys`. The private key is a secret (redacted in logs). Subject: `mailto:` or `https:` |
| SOCKET_IO_ENABLED / SOCKET_IO_PATH / SOCKET_IO_PING_INTERVAL_MS / SOCKET_IO_PING_TIMEOUT_MS / SOCKET_IO_MAX_CONNECTIONS_PER_USER | true / `/socket.io` / 25000 / 20000 / 20 | Real-time notifications over Socket.IO (Module 31, see `docs/NOTIFICATIONS.md`). Portable: same HTTP server, no hosting-specific value. `false` = Web Push and the notification APIs only. |
| OTP_HMAC_SECRET | empty | **required in production**, ≥ 32 chars, must differ from both JWT secrets (dedicated key for OTP / reset-token hashing) |
| OTP_SENDER | disabled | `disabled` or `dev-file` (development only; rejected in production) |
| TRUSTED_PROXIES | empty (none trusted) | comma-separated IPs, CIDR ranges or `loopback`/`linklocal`/`uniquelocal`; `true`, hop counts, `*` and `/0` ranges are rejected |
| API_DOCS_ENABLED | `true` outside production, `false` in production | `true` or `false`. Serves Swagger UI at `/api-docs` and the raw OpenAPI document at `/api-docs.json` (see `docs/API-DOCUMENTATION.md`); production exposure requires an explicit `true` |
| REDIS_HOST / PORT | 127.0.0.1 / 6379 | port 1–65535 |
| FILE_STORAGE_PATH | ./storage | |
| MAX_FILE_SIZE | 10485760 | positive integer (bytes) |

Use `redactConfig(config)` whenever configuration must be logged.

Note: `database/config.cjs` (sequelize-cli) reads the same `DATABASE_*` variables directly because the CLI runs outside the app.
