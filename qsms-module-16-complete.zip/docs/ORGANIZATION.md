# Main Organization (Module 13)

Owns the Main Organization entity, its table `organizations`, its migrations and its rules. V1 has **exactly one** organization. No HTTP endpoints, no permissions, no deletion.

## Model (approved fields only)
| Field | Rule |
|---|---|
| `id` | UUID (technical identifier) |
| `code` | unique, `ORG-000001` format (CHECK + unique index); generated as the next free sequence |
| `name` | one required field, Arabic **or** English. Normalized (Unicode NFC, trimmed, whitespace runs collapsed). Rejected: empty/whitespace-only, control characters, more than 200 characters. Column `VARCHAR(200)` in a `utf8mb4` / `utf8mb4_unicode_ci` table |
| `status` | `ACTIVE` or `INACTIVE` (CHECK). Created ACTIVE. **No transition operation exists** (none is specified) |
| `country_id` | the Main Organization's country: the **primary key** (`CHAR(36)`, same type as `countries.id`) of a `countries` row, never a country code such as `CNT-000001`. Nullable until assigned. Foreign key `fk_organizations_country` → `countries.id`, `ON DELETE RESTRICT` / `ON UPDATE RESTRICT` (migration `20261011100000-add-organizations-country`). **Immutable once assigned (V1).** All branches, schools and users of the organization belong to this country, so it is the only source of the country in any address |
| `created_at`, `updated_at` | `DATETIME(3)`, UTC (project convention) |

Plus `v1_single_guard` (technical column, always 1).

## Single-organization rule (enforced by the database)
`v1_single_guard` has `CHECK (v1_single_guard = 1)` and a UNIQUE index, so a second row is impossible, even inactive and even with a different code. The repository maps the violation to `ORGANIZATION_ALREADY_EXISTS`. For a future multi-organization version: a new migration drops `uq_organizations_v1_single` (and the column); nothing else assumes one row. The code sequence is already generated per row (`MAX + 1`), and `findById` exists next to `getMainOrganization`.

## Creation: bootstrap only, idempotent
- `npm run bootstrap:organization`: asks the name (only if no organization exists) and creates it. Re-running only reports the existing one (exit 0, no prompt, nothing changed, no event). Use it on an installation whose Main Admin already exists.
- `npm run bootstrap:main-admin`: runs the **same step first**, then creates the Main Admin (Module 12). If the organization step fails, no Main Admin is created.
- Order for a fresh install: `npm run db:migrate`, then `npm run bootstrap:main-admin`.
- `OrganizationService.ensureMainOrganization(name)`: existing organization returned **unchanged** (a different name is ignored: never renamed); otherwise one transaction inserts the row and writes the `OrganizationCreated` event. A concurrent creator that loses the database race is rolled back (row and event) and receives the winner's row (`created: false`). An invalid name is rejected even when an organization exists.

## Country of the Main Organization (immutable in V1)
- **Assigning:** `npm run bootstrap:organization` (after `npm run db:migrate` and `npm run seed:geography`) assigns **Egypt** after the organization step. `npm run bootstrap:main-admin` runs the same step but it is advisory there (see below). The CLI resolves the country **by code `CNT-000001`** and stores the **primary key** of that `countries` row in `organizations.country_id`.
- **Safety checks (always, also with `--yes`):** the organization must exist; an already assigned country is never changed (the same country is only reported, a different one is reported as a CONFLICT and the step stops); `CNT-000001` must exist, be named exactly `مصر` and be ACTIVE, otherwise nothing is changed and the reason is printed (for example "run `npm run seed:geography` first").
- **Confirmation:** interactive confirmation by default. `npm run bootstrap:organization -- --yes` skips **only** that prompt (for explicitly approved scripted runs). A non-interactive run without `--yes` exits with the usage code (2) and changes nothing. Re-running is safe (idempotent: "already CNT-000001, nothing changed").
- **In `bootstrap:main-admin`:** the country step always asks for confirmation and a failure does not block creating the Main Admin (a fresh install may not have run the geography seed yet); it prints how to assign the country later.
- **Immutability, enforced in the application:** `Organization.assignCountry` (domain) accepts a country only when none is set, treats the same country as an idempotent no-op (no event) and rejects a different one (`ORGANIZATION_COUNTRY_ALREADY_SET`). Persistence uses one atomic, set-once statement `UPDATE organizations SET country_id = :id WHERE id = :organizationId AND country_id IS NULL` after locking the row (`FOR UPDATE`). No other code path updates `organizations`; the module has no update or delete operation. A value that is not a UUID (for example the code `CNT-000001`) is rejected with `ORGANIZATION_COUNTRY_INVALID` before the database is touched; a UUID that is not a `countries` row is rejected by the foreign key and mapped to the same code.
- **Not prevented:** there is **no database trigger**. A direct SQL `UPDATE` performed outside the application is not blocked by this rule (approved decision); the foreign key only guarantees that the stored value is an existing country.
- **Fails closed:** `requireMainOrganizationCountryId()` throws `ORGANIZATION_COUNTRY_NOT_SET` until a country is assigned; Module 15 therefore rejects every Parent Address until then.

## Events
- `OrganizationCreated` (aggregate `Organization`), payload `{ organizationId, code }` (identifiers only), written through the existing outbox in the same transaction as the row. Emitted once, never on re-runs.
- `OrganizationCountryAssigned` (aggregate `Organization`), payload `{ organizationId, countryId }` (identifiers only; `countryId` is the `countries.id` primary key), written in the same transaction as the country assignment. Emitted once, never when the same country is assigned again. It is the audit record of the assignment (together with `updated_at`).

## Public contract (`src/modules/13-organization-core/public`)
Downstream modules depend on `OrganizationLookup` (read-only): `getMainOrganization(tx?) -> OrganizationDto | undefined`, `requireMainOrganization(tx?)` (throws `ORGANIZATION_NOT_FOUND`), `findById(id, tx?)`. `requireMainOrganizationCountryId(tx?)` returns the country primary key (throws `ORGANIZATION_NOT_FOUND` or `ORGANIZATION_COUNTRY_NOT_SET`). `OrganizationDto = { id, code, name, status, countryId, createdAt, updatedAt }` (`countryId: string | null`). Composition root: `getOrganizationService()` in `src/config/organization.ts`. Errors (ar/en): `INVALID_ORGANIZATION_NAME`, `ORGANIZATION_ALREADY_EXISTS`, `ORGANIZATION_NOT_FOUND`, `ORGANIZATION_COUNTRY_ALREADY_SET`, `ORGANIZATION_COUNTRY_NOT_SET`, `ORGANIZATION_COUNTRY_INVALID`. `assignMainOrganizationCountry(countryId)` exists for the bootstrap CLI only (no endpoint).

## Notes for downstream modules
- **Foreign keys:** a later table may reference `organizations.id` (CHAR(36)) with `ON DELETE RESTRICT` (approved default). That does not allow importing this module's internals or querying its table from application code: use `OrganizationLookup`.
- **Geography (14):** the specification defines Country → Governorate → Center/City → Village → School as master data and does not make it organization-owned, so geography is treated as global and Country is **not** a child of the organization. The organization only *references* its country (`country_id`). Module 13 does not import Module 14: the CLI resolves the country through `GeographyLookup` and the foreign key is the final guard. The module map still lists 13 as a dependency of 14; Module 14's review must confirm what it actually needs from 13 (probably nothing beyond the lookup).
- **Schools (16):** the specification lists "organization" among school-creation fields, so a school references the Main Organization (`organizations.id`). Approved for Module 16: an INACTIVE organization blocks creating schools (`SCHOOL_ORGANIZATION_INACTIVE`), and school names are unique per organization. See `docs/SCHOOLS.md`.
- **Open, needed only by Module 16:** the "Main Admin relationship" in school creation is not defined. It could be the creating user, an audit/creator reference, or a business relationship. It is **not** modeled here; one focused question will be asked when Module 16 is reviewed.
- Status changes (activate/deactivate) and any organization-management endpoint or permission are not implemented; they need their requirements first. `docs/AUTHORIZATION-MATRIX.md` is unchanged: Module 13 adds no operation that needs authorization.

## Tests
Unit: `tests/unit/organization` (name/code/status rules, idempotent bootstrap, race recovery, event, in-memory V1 rule, CLI step and integration with the Main Admin CLI; `organization-country.test.ts` country rules and `organization-country-cli.test.ts` the country CLI step, including `--yes`, conflicts and the primary-key-not-code rule). MariaDB: `tests/db/organizations.test.ts` (schema, Arabic round trip, atomic row + event, rollback, idempotency, race via the DB guard, CHECK/unique guards) and `tests/db/organization-country.test.ts` (column type equals `countries.id`, RESTRICT foreign key, primary key stored, one event, immutability, set-once UPDATE, code and unknown id rejected, country cannot be deleted while used). The DB tests run in one always-rolled-back transaction, so they are safe on a database that already has an organization.
